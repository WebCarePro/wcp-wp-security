<?php
namespace WebCareProScanner\Notifications;

use WebCareProScanner\System\SettingsManager;
use WebCareProScanner\Notifications\WebhookService;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * NotificationDispatcher
 *
 * Centralized, multi-channel security notification engine.
 * Dispatches granular security events to Email (wp_mail) and DevSecOps Webhooks
 * (Slack, Discord, ClickUp, Asana, Custom JSON) based on developer configuration.
 */
class NotificationDispatcher {

    /**
     * Map of event definitions with human-readable titles, descriptions, categories, and default severities.
     */
    public static function get_event_catalog(): array {
        return [
            // Category: Scans
            'scan_scheduled_complete' => [
                'category'    => 'scans',
                'category_label' => __('Core Scans & Threats', 'webcare-pro-security'),
                'title'       => __('Scheduled Scan Complete', 'webcare-pro-security'),
                'description' => __('Fires when an automated background cron scan finishes auditing the site.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'scan_manual_complete' => [
                'category'    => 'scans',
                'category_label' => __('Core Scans & Threats', 'webcare-pro-security'),
                'title'       => __('Manual Scan Complete', 'webcare-pro-security'),
                'description' => __('Fires when an on-demand scan manually started from the dashboard finishes.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'scan_targeted_complete' => [
                'category'    => 'scans',
                'category_label' => __('Core Scans & Threats', 'webcare-pro-security'),
                'title'       => __('Targeted Scan Complete', 'webcare-pro-security'),
                'description' => __('Fires when an audit targeting a specific directory, theme, or file list concludes.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'scan_threats_found' => [
                'category'    => 'scans',
                'category_label' => __('Core Scans & Threats', 'webcare-pro-security'),
                'title'       => __('Critical / High Threats Detected', 'webcare-pro-security'),
                'description' => __('Dispatches immediately when severe vulnerabilities, backdoors, or malicious webshells are discovered.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'scan_auto_quarantine' => [
                'category'    => 'scans',
                'category_label' => __('Core Scans & Threats', 'webcare-pro-security'),
                'title'       => __('Auto-Quarantined Malicious Threat', 'webcare-pro-security'),
                'description' => __('Fires when an active exploit or malicious payload is safely neutralized into the WebCare Vault.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'scan_aborted_timeout' => [
                'category'    => 'scans',
                'category_label' => __('Core Scans & Threats', 'webcare-pro-security'),
                'title'       => __('Scan Aborted / Execution Timeout', 'webcare-pro-security'),
                'description' => __('Alerts when a running security scan stalls, aborts due to PHP memory limits, or times out.', 'webcare-pro-security'),
                'severity'    => 'warning',
            ],

            // Category: Self Defense
            'plugin_file_tampered' => [
                'category'    => 'self_defense',
                'category_label' => __('Plugin Self-Defense', 'webcare-pro-security'),
                'title'       => __('Plugin File Tampering / Hash Mismatch', 'webcare-pro-security'),
                'description' => __('Fires if any core file of WebCare Pro Security has been modified or injected with rogue code.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'plugin_file_missing' => [
                'category'    => 'self_defense',
                'category_label' => __('Plugin Self-Defense', 'webcare-pro-security'),
                'title'       => __('Plugin File Missing / Deleted', 'webcare-pro-security'),
                'description' => __('Fires if a required plugin file was deleted by host scanners, mod_security, or an intruder.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'plugin_deactivate_attempt' => [
                'category'    => 'self_defense',
                'category_label' => __('Plugin Self-Defense', 'webcare-pro-security'),
                'title'       => __('Unauthorized Plugin Deactivation', 'webcare-pro-security'),
                'description' => __('Alerts when an administrator or external script attempts to deactivate WebCare Pro Security.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'plugin_uninstall' => [
                'category'    => 'self_defense',
                'category_label' => __('Plugin Self-Defense', 'webcare-pro-security'),
                'title'       => __('Plugin Uninstallation Event', 'webcare-pro-security'),
                'description' => __('Fires when WebCare Pro Security is deleted from WordPress plugins manager.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],

            // Category: Cloudflare & WAF
            'cf_firewall_updated' => [
                'category'    => 'cloudflare_waf',
                'category_label' => __('Cloudflare & WAF Defense', 'webcare-pro-security'),
                'title'       => __('Cloudflare Firewall Rule Deployed/Updated', 'webcare-pro-security'),
                'description' => __('Notifies when an edge firewall rule, IP block, or rate limit is synchronized with Cloudflare.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'cf_firewall_rule_deleted' => [
                'category'    => 'cloudflare_waf',
                'category_label' => __('Cloudflare & WAF Defense', 'webcare-pro-security'),
                'title'       => __('Cloudflare Firewall Rule Removed', 'webcare-pro-security'),
                'description' => __('Alerts when an active edge security rule or IP ban is removed from Cloudflare.', 'webcare-pro-security'),
                'severity'    => 'warning',
            ],
            'waf_block_surge' => [
                'category'    => 'cloudflare_waf',
                'category_label' => __('Cloudflare & WAF Defense', 'webcare-pro-security'),
                'title'       => __('WAF Block Surge / Attack Spike', 'webcare-pro-security'),
                'description' => __('Dispatches when WAF Lite intercepts an abnormal surge of blocked malicious HTTP requests.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'waf_virtual_patch_hit' => [
                'category'    => 'cloudflare_waf',
                'category_label' => __('Cloudflare & WAF Defense', 'webcare-pro-security'),
                'title'       => __('Virtual Patch Exploit Intercepted', 'webcare-pro-security'),
                'description' => __('Fires when an unpatched plugin or zero-day vulnerability payload is blocked by virtual patching.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'waf_server_rules_updated' => [
                'category'    => 'cloudflare_waf',
                'category_label' => __('Cloudflare & WAF Defense', 'webcare-pro-security'),
                'title'       => __('Server Security Rules Updated (.htaccess/Nginx)', 'webcare-pro-security'),
                'description' => __('Notifies when hardening directives are appended or updated in web server configuration files.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'redirect_hack_detected' => [
                'category'    => 'cloudflare_waf',
                'category_label' => __('Cloudflare & WAF Defense', 'webcare-pro-security'),
                'title'       => __('Zero-Day Redirect Hack / Hijack Intercepted', 'webcare-pro-security'),
                'description' => __('Critical alert when a malicious .htaccess redirect, search/mobile cloaker, or runtime PHP redirection is detected.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'redirect_hack_auto_healed' => [
                'category'    => 'cloudflare_waf',
                'category_label' => __('Cloudflare & WAF Defense', 'webcare-pro-security'),
                'title'       => __('Redirect Hack Remediated / .htaccess Restored', 'webcare-pro-security'),
                'description' => __('Notifies when a tampered .htaccess is automatically restored from the vault and all site caches are purged.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],

            // Category: Authentication & 2FA
            'auth_admin_login' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('Administrator Login Successful', 'webcare-pro-security'),
                'description' => __('Dispatches an immediate alert whenever an administrator user logs in to WordPress.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'auth_admin_password_reset' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('Admin Password Changed / Reset', 'webcare-pro-security'),
                'description' => __('Alerts when an administrator password is reset or updated via profile, recovery link, or REST API.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'auth_application_password_created' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('New Application Password Created', 'webcare-pro-security'),
                'description' => __('Dispatches an immediate alert whenever a new WordPress Application Password is generated.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'auth_2fa_enabled' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('Two-Factor Authentication (2FA) Activated', 'webcare-pro-security'),
                'description' => __('Notifies when an administrator or user sets up TOTP multi-factor authentication.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'auth_2fa_disabled' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('2FA Deactivated / Emergency Code Used', 'webcare-pro-security'),
                'description' => __('Fires when 2FA is removed from an administrator profile or an emergency recovery code is spent.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'auth_bruteforce_lockout' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('Brute-Force Lockout Triggered', 'webcare-pro-security'),
                'description' => __('Dispatches when an offensive IP address exceeds maximum login failures and is locked out.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'auth_cf_edge_ban_synced' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('Cloudflare Edge IP Ban Synchronized', 'webcare-pro-security'),
                'description' => __('Notifies when a locked-out brute-force IP is escalated to Cloudflare edge WAF ruleset.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'auth_session_hijack_flag' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('Session IP Shift / Potential Hijack', 'webcare-pro-security'),
                'description' => __('Alerts when an active logged-in admin session abruptly changes IP address or user-agent fingerprint.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'auth_rogue_admin_created' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('Unauthorized / Rogue Admin User Created', 'webcare-pro-security'),
                'description' => __('Fires immediately if a new administrator or super-admin account is registered.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'auth_app_password_consent_trap' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('Application Password Phishing Trap Blocked', 'webcare-pro-security'),
                'description' => __('Dispatches an immediate alert when an unauthorized external callback URL attempts to steal an Application Password via authorize-application.php.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],

            // Category: File Integrity Monitoring (FIM)
            'fim_core_file_modified' => [
                'category'    => 'fim',
                'category_label' => __('File Integrity Monitoring (FIM)', 'webcare-pro-security'),
                'title'       => __('WordPress Core File Modified', 'webcare-pro-security'),
                'description' => __('Alerts when an official WordPress core system file checksum differs from the official release.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'fim_plugin_theme_modified' => [
                'category'    => 'fim',
                'category_label' => __('File Integrity Monitoring (FIM)', 'webcare-pro-security'),
                'title'       => __('Plugin or Theme File Modified', 'webcare-pro-security'),
                'description' => __('Fires when changes are detected in an official WordPress.org plugin or active theme folder.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'fim_suspicious_php_found' => [
                'category'    => 'fim',
                'category_label' => __('File Integrity Monitoring (FIM)', 'webcare-pro-security'),
                'title'       => __('Rogue PHP Script Discovered in Uploads', 'webcare-pro-security'),
                'description' => __('Critical alert when an executable PHP/PHTML script is discovered inside media or cache directories.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'fim_auto_cure_applied' => [
                'category'    => 'fim',
                'category_label' => __('File Integrity Monitoring (FIM)', 'webcare-pro-security'),
                'title'       => __('Auto-Cure Restored Pristine File', 'webcare-pro-security'),
                'description' => __('Notifies when FIM Auto-Cure automatically repairs an altered core or plugin file from pristine source.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'fim_baseline_refreshed' => [
                'category'    => 'fim',
                'category_label' => __('File Integrity Monitoring (FIM)', 'webcare-pro-security'),
                'title'       => __('FIM Baseline Snapshot Refreshed', 'webcare-pro-security'),
                'description' => __('Fires when the file integrity baseline checksum database is newly generated or recalculated.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'object_cache_poisoning_detected' => [
                'category'    => 'fim',
                'category_label' => __('File Integrity Monitoring (FIM)', 'webcare-pro-security'),
                'title'       => __('In-Memory Object Cache Poisoning Detected', 'webcare-pro-security'),
                'description' => __('Critical alert when Redis, Memcached, or RAM object cache options diverge from MySQL database truth, indicating fileless in-memory tampering.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],

            // Category: Vulnerabilities (CVE)
            'vuln_core_cve_detected' => [
                'category'    => 'vulnerabilities',
                'category_label' => __('Vulnerabilities & CVE Feeds', 'webcare-pro-security'),
                'title'       => __('WordPress Core Known CVE Found', 'webcare-pro-security'),
                'description' => __('Critical warning when the installed WordPress version is affected by an unpatched CVE advisory.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'vuln_plugin_theme_cve' => [
                'category'    => 'vulnerabilities',
                'category_label' => __('Vulnerabilities & CVE Feeds', 'webcare-pro-security'),
                'title'       => __('Plugin / Theme Vulnerability Advisory Flagged', 'webcare-pro-security'),
                'description' => __('Dispatches when an installed plugin or theme has a known security bulletin or exploit published.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'vuln_abandoned_extension' => [
                'category'    => 'vulnerabilities',
                'category_label' => __('Vulnerabilities & CVE Feeds', 'webcare-pro-security'),
                'title'       => __('Abandoned or Closed Plugin Detected', 'webcare-pro-security'),
                'description' => __('Notifies when a plugin is removed from the WordPress.org repository due to security issues or neglect.', 'webcare-pro-security'),
                'severity'    => 'warning',
            ],
            'vuln_feed_synced' => [
                'category'    => 'vulnerabilities',
                'category_label' => __('Vulnerabilities & CVE Feeds', 'webcare-pro-security'),
                'title'       => __('Threat Intelligence Feed Synchronized', 'webcare-pro-security'),
                'description' => __('Fires when local vulnerability definitions and community IP blacklists update successfully.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],

            // Category: Backups & Vault
            'backup_db_completed' => [
                'category'    => 'backups_vault',
                'category_label' => __('Database Backups & Vault', 'webcare-pro-security'),
                'title'       => __('Database Backup Completed', 'webcare-pro-security'),
                'description' => __('Notifies when a full compressed database backup archive is created successfully.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'backup_db_failed' => [
                'category'    => 'backups_vault',
                'category_label' => __('Database Backups & Vault', 'webcare-pro-security'),
                'title'       => __('Database Backup Failed / Aborted', 'webcare-pro-security'),
                'description' => __('Urgent alert when database backup export fails due to disk space or database permissions.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'backup_db_restored' => [
                'category'    => 'backups_vault',
                'category_label' => __('Database Backups & Vault', 'webcare-pro-security'),
                'title'       => __('Database Restored From Backup', 'webcare-pro-security'),
                'description' => __('Critical notification when a database restore operation is executed from an archive.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'vault_quarantine_restored' => [
                'category'    => 'backups_vault',
                'category_label' => __('Database Backups & Vault', 'webcare-pro-security'),
                'title'       => __('Quarantined File Restored to Filesystem', 'webcare-pro-security'),
                'description' => __('Alerts when a file previously placed in security quarantine is restored back to active disk.', 'webcare-pro-security'),
                'severity'    => 'warning',
            ],
            'vault_quarantine_deleted' => [
                'category'    => 'backups_vault',
                'category_label' => __('Database Backups & Vault', 'webcare-pro-security'),
                'title'       => __('Quarantined File Permanently Purged', 'webcare-pro-security'),
                'description' => __('Fires when malicious files in quarantine storage are permanently erased from disk.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],

            // Category: DevSecOps & AI
            'webhook_status_toggled' => [
                'category'    => 'devsecops_ai',
                'category_label' => __('DevSecOps & AI Forensics', 'webcare-pro-security'),
                'title'       => __('Webhook Channel Enabled / Disabled', 'webcare-pro-security'),
                'description' => __('Notifies when Slack, Discord, ClickUp, Asana, or custom webhooks are turned on or off.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'webhook_delivery_failed' => [
                'category'    => 'devsecops_ai',
                'category_label' => __('DevSecOps & AI Forensics', 'webcare-pro-security'),
                'title'       => __('Webhook HTTP Delivery Error', 'webcare-pro-security'),
                'description' => __('Alerts via email when a security webhook fails to deliver after multiple HTTP retries.', 'webcare-pro-security'),
                'severity'    => 'warning',
            ],
            'ai_forensics_toggled' => [
                'category'    => 'devsecops_ai',
                'category_label' => __('DevSecOps & AI Forensics', 'webcare-pro-security'),
                'title'       => __('AI Code Forensics Engine Toggled', 'webcare-pro-security'),
                'description' => __('Notifies when Gemini / OpenAI / Claude deep forensic analysis is enabled or disabled.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'mcp_service_toggled' => [
                'category'    => 'devsecops_ai',
                'category_label' => __('DevSecOps & AI Forensics', 'webcare-pro-security'),
                'title'       => __('MCP AI Agent Service Surface Toggled', 'webcare-pro-security'),
                'description' => __('Fires when Model Context Protocol agent API access is toggled on or off.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            // Category: Supply-Chain Defense & SBOM
            'supply_chain_anchor_tampered' => [
                'category'    => 'supply_chain',
                'category_label' => __('Supply-Chain Defense & SBOM', 'webcare-pro-security'),
                'title'       => __('Runtime Anchor / Drop-in Tampering Detected', 'webcare-pro-security'),
                'description' => __('Fires when a cryptographic hash mismatch or stealth modification is detected in object-cache.php, db.php, or advanced-cache.php.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'supply_chain_gatekeeper_blocked' => [
                'category'    => 'supply_chain',
                'category_label' => __('Supply-Chain Defense & SBOM', 'webcare-pro-security'),
                'title'       => __('Hostile Plugin Update Intercepted by Gatekeeper', 'webcare-pro-security'),
                'description' => __('Alerts immediately when an automated or manual plugin update contains critical webshells, obfuscated payloads, or unauthorized mutations.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'supply_chain_gatekeeper_rollback' => [
                'category'    => 'supply_chain',
                'category_label' => __('Supply-Chain Defense & SBOM', 'webcare-pro-security'),
                'title'       => __('Pre-Install Gatekeeper Rollback Executed', 'webcare-pro-security'),
                'description' => __('Notifies when a hazardous plugin update is reverted back to its verified pre-install snapshot.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'supply_chain_risk_advisor_alert' => [
                'category'    => 'supply_chain',
                'category_label' => __('Supply-Chain Defense & SBOM', 'webcare-pro-security'),
                'title'       => __('High-Risk Plugin Installation Flagged', 'webcare-pro-security'),
                'description' => __('Dispatches when Shift-Left Risk Analyzer detects critical risk signals, abandoned code, or severe supply-chain flags.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'supply_chain_lockfile_cve' => [
                'category'    => 'supply_chain',
                'category_label' => __('Supply-Chain Defense & SBOM', 'webcare-pro-security'),
                'title'       => __('Vulnerable Dependency in Lockfile (Composer / NPM)', 'webcare-pro-security'),
                'description' => __('Alerts when known CVE vulnerabilities or supply-chain advisories match packages in composer.lock or package-lock.json.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'supply_chain_script_drift' => [
                'category'    => 'supply_chain',
                'category_label' => __('Supply-Chain Defense & SBOM', 'webcare-pro-security'),
                'title'       => __('Client JS Drift / Unauthorized Remote Hostname', 'webcare-pro-security'),
                'description' => __('Fires when newly enqueued frontend JavaScript loads from an uncalibrated third-party domain or external CDN.', 'webcare-pro-security'),
                'severity'    => 'warning',
            ],

            // Category: Behavioral WAF & Active Traps
            'behavioral_bot_trap_triggered' => [
                'category'    => 'behavioral',
                'category_label' => __('Behavioral WAF & Active Traps', 'webcare-pro-security'),
                'title'       => __('Behavioral Honeytoken / Ghost Route Tripped', 'webcare-pro-security'),
                'description' => __('Fires when an automated crawler, scraper, or scanner touches hidden ghost routes or deceptive canary endpoints.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'behavioral_rate_limit_exceeded' => [
                'category'    => 'behavioral',
                'category_label' => __('Behavioral WAF & Active Traps', 'webcare-pro-security'),
                'title'       => __('Behavioral Rate Anomaly Fence Tripped', 'webcare-pro-security'),
                'description' => __('Dispatches when an offensive IP exceeds heuristic burst frequency thresholds across critical endpoints.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'ai_defense_prompt_injection' => [
                'category'    => 'behavioral',
                'category_label' => __('Behavioral WAF & Active Traps', 'webcare-pro-security'),
                'title'       => __('AI Prompt Injection & Jailbreak Decoy Intercepted', 'webcare-pro-security'),
                'description' => __('Alerts when malicious system-prompt override attempts, adversarial jailbreaks, or LLM scraping probes are terminated.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'distributed_botnet_attack_detected' => [
                'category'       => 'behavioral',
                'category_label' => __('Behavioral WAF & Active Traps', 'webcare-pro-security'),
                'title'          => __('Distributed Botnet Attack / Under-Attack Mode Activated', 'webcare-pro-security'),
                'description'    => __('Alerts when cross-IP distributed velocity triggers an automated Under-Attack lockdown against credential stuffing or carding swarms.', 'webcare-pro-security'),
                'severity'       => 'critical',
            ],
            'db_canary_tripwire_breach' => [
                'category'       => 'behavioral',
                'category_label' => __('Behavioral WAF & Active Traps', 'webcare-pro-security'),
                'title'          => __('Database Canary / Ghost Admin Tripwire Breach', 'webcare-pro-security'),
                'description'    => __('Alerts when an unauthorized attacker attempts to authenticate as the dormant Ghost Admin canary or accesses decoy database honey options.', 'webcare-pro-security'),
                'severity'       => 'critical',
            ],
            'attack_drill_completed' => [
                'category'    => 'behavioral',
                'category_label' => __('Behavioral WAF & Active Traps', 'webcare-pro-security'),
                'title'       => __('Red Team Attack Drill Simulation Finished', 'webcare-pro-security'),
                'description' => __('Summarizes firewall defensibility, payload interception ratios, and alert responsiveness upon drill completion.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],

            // Category: Zero-Trust Identity & Session Forensics
            'auth_passkey_registered' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('FIDO2 / WebAuthn Biometric Passkey Enrolled', 'webcare-pro-security'),
                'description' => __('Notifies when an administrator binds a new biometric credential, YubiKey, or hardware passkey.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'auth_passkey_revoked' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('WebAuthn Hardware Passkey Revoked / Deleted', 'webcare-pro-security'),
                'description' => __('Alerts when a hardware security key or biometric credential is removed from an account.', 'webcare-pro-security'),
                'severity'    => 'warning',
            ],
            'auth_temporary_access_granted' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('JIT Ephemeral Administrator Elevation Granted', 'webcare-pro-security'),
                'description' => __('Notifies when temporary Just-In-Time administrative privileges are granted to an existing user account.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'auth_temporary_access_revoked' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('JIT Ephemeral Elevation Revoked / Expired', 'webcare-pro-security'),
                'description' => __('Fires when a temporary elevation session is manually terminated or automatically expired back to baseline privileges.', 'webcare-pro-security'),
                'severity'    => 'info',
            ],
            'auth_impossible_travel_flag' => [
                'category'    => 'auth',
                'category_label' => __('Authentication & Access Security', 'webcare-pro-security'),
                'title'       => __('Impossible Geo-Velocity Travel Anomaly Detected', 'webcare-pro-security'),
                'description' => __('Critical alert when an admin account authenticates from two distant geographical locations in an impossible timeframe.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],

            // Category: Advanced Forensics, Vault & Quarantine
            'forensics_reinfection_resurrection' => [
                'category'    => 'backups_vault',
                'category_label' => __('Database Backups & Vault', 'webcare-pro-security'),
                'title'       => __('72-Hour Watchdog: Malware Resurrection Intercepted', 'webcare-pro-security'),
                'description' => __('Urgent alert when a previously cleaned or quarantined file is recreated by persistent rogue crons or hidden web shells.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'vault_secrets_rotated' => [
                'category'    => 'backups_vault',
                'category_label' => __('Database Backups & Vault', 'webcare-pro-security'),
                'title'       => __('Secrets Vault Master Key / Cryptographic Salt Rotated', 'webcare-pro-security'),
                'description' => __('Notifies when master encryption keys or authentication salts are re-encrypted and safely rotated in wp-config.php.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],
            'remediation_transaction_rollback' => [
                'category'    => 'backups_vault',
                'category_label' => __('Database Backups & Vault', 'webcare-pro-security'),
                'title'       => __('Atomic Remediation Transaction Reverted', 'webcare-pro-security'),
                'description' => __('Fires when an administrative rollback action restores previous file, database, or user states from a transaction log.', 'webcare-pro-security'),
                'severity'    => 'warning',
            ],

            // Category: Emergency Containment Protocol
            'containment_mode_activated' => [
                'category'    => 'self_defense',
                'category_label' => __('Plugin Self-Defense', 'webcare-pro-security'),
                'title'       => __('1-Click Incident Containment Protocol ACTIVATED', 'webcare-pro-security'),
                'description' => __('Emergency broadcast: Host egress severed, unauthorized admin sessions frozen, and public maintenance lockdown engaged.', 'webcare-pro-security'),
                'severity'    => 'critical',
            ],
            'containment_mode_deactivated' => [
                'category'    => 'self_defense',
                'category_label' => __('Plugin Self-Defense', 'webcare-pro-security'),
                'title'       => __('Incident Containment Protocol Disengaged', 'webcare-pro-security'),
                'description' => __('Notifies when emergency containment lockdown is lifted and normal platform operations resume.', 'webcare-pro-security'),
                'severity'    => 'high',
            ],

            // Category: Executive Digests
            'weekly_peace_of_mind_digest' => [
                'category'       => 'executive_digests',
                'category_label' => __('Executive Reports & Digests', 'webcare-pro-security'),
                'title'          => __('Monday Morning Peace-of-Mind Digest', 'webcare-pro-security'),
                'description'    => __('Calm weekly Monday summary of blocked threats, WooCommerce checkout defenses, and verified clean files. Disabled by default.', 'webcare-pro-security'),
                'severity'       => 'info',
            ],
        ];
    }

    /**
     * Detect client browser device type (Desktop, Mobile, Tablet)
     */
    public static function detect_device_type(): string {
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower(sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT']))) : '';
        if (empty($ua)) {
            return 'Unknown Device';
        }
        if (strpos($ua, 'ipad') !== false || strpos($ua, 'tablet') !== false || strpos($ua, 'playbook') !== false) {
            return 'Tablet';
        }
        if (strpos($ua, 'mobile') !== false || strpos($ua, 'iphone') !== false || strpos($ua, 'android') !== false || strpos($ua, 'blackberry') !== false) {
            return 'Mobile';
        }
        return 'Desktop';
    }

    /**
     * Detect real client IP address respecting Cloudflare, proxy headers, and direct remote address
     */
    public static function get_real_client_ip(): string {
        $headers = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_REAL_IP',
            'HTTP_X_FORWARDED_FOR',
            'REMOTE_ADDR'
        ];
        foreach ($headers as $h) {
            if (!empty($_SERVER[$h])) {
                $raw_val = sanitize_text_field(wp_unslash($_SERVER[$h]));
                $ips = explode(',', $raw_val);
                $ip = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '127.0.0.1';
    }

    /**
     * Check if a specific notification event channel is enabled.
     *
     * @param string $event_key Event identifier
     * @param string $channel 'email' or 'webhook'
     * @return bool
     */
    public static function is_event_enabled(string $event_key, string $channel = 'email'): bool {
        $settings = SettingsManager::get_settings();
        if (empty($settings['notification_master_enabled'])) {
            return false;
        }

        $events_config = $settings['notification_events'] ?? [];
        $event_cfg = $events_config[$event_key] ?? null;

        if ($event_cfg === null) {
            $defaults = SettingsManager::get_default_notification_events();
            $event_cfg = $defaults[$event_key] ?? ['email' => false, 'webhook' => false];
        }

        return !empty($event_cfg[$channel]);
    }

    /**
     * Trigger a granular security event notification
     *
     * @param string $event_key
     * @param array $payload Key-value context (e.g. ['title' => '...', 'message' => '...', 'details' => ...])
     * @return array Results per channel ['email' => bool|null, 'webhook' => bool|null]
     */
    public static function trigger(string $event_key, array $payload = []): array {
        $settings = SettingsManager::get_settings();

        // 1. Check global master switch
        if (empty($settings['notification_master_enabled'])) {
            return ['skipped' => 'master_disabled', 'email' => null, 'webhook' => null];
        }

        $events_config = $settings['notification_events'] ?? [];
        $event_cfg = $events_config[$event_key] ?? null;

        // Fallback to default catalog if missing
        if ($event_cfg === null) {
            $defaults = SettingsManager::get_default_notification_events();
            $event_cfg = $defaults[$event_key] ?? ['email' => false, 'webhook' => false];
        }

        $catalog = self::get_event_catalog();
        $meta = $catalog[$event_key] ?? [
            'title'       => ucwords(str_replace('_', ' ', $event_key)),
            'description' => '',
            'severity'    => 'info',
        ];

        // Contextual user & execution intelligence
        $is_cli = (php_sapi_name() === 'cli') || defined('WP_CLI');
        $is_cron = defined('DOING_CRON') && DOING_CRON;
        $is_system = $is_cli || $is_cron;

        $current_user = function_exists('wp_get_current_user') ? wp_get_current_user() : null;
        $admin_username = ($current_user && $current_user->exists()) ? $current_user->user_login : null;
        $client_ip = self::get_real_client_ip();
        $device_type = self::detect_device_type();
        $gmt_time = gmdate('Y-m-d H:i:s') . ' GMT';

        // Prepare standard developer-friendly details
        $enhanced_details = [];

        // Check if explicitly passed or extract
        $incoming_details = $payload['details'] ?? [];

        // 1. Triggered By (with Real Client IP)
        $plugin_ver = defined('WEBCAREPROSCAN_VERSION') ? WEBCAREPROSCAN_VERSION : '2.7.1';
        $enhanced_details['Scanner Version'] = 'v' . $plugin_ver;

        if (!empty($admin_username)) {
            $enhanced_details['Triggered By'] = sprintf('%s (%s)', $admin_username, $client_ip);
            // Mention device/browser only if triggered by an authenticated admin user (not system auto generated)
            $enhanced_details['User Browser Type'] = $device_type;
        } elseif (!empty($incoming_details['triggered_by'])) {
            $user_str = (string)$incoming_details['triggered_by'];
            if (strpos($user_str, '(') === false) {
                $enhanced_details['Triggered By'] = sprintf('%s (%s)', $user_str, $client_ip);
            } else {
                $enhanced_details['Triggered By'] = $user_str;
            }
            if (!$is_system) {
                $enhanced_details['User Browser Type'] = $device_type;
            }
        } elseif ($is_cron) {
            $enhanced_details['Triggered By'] = 'Automated WP-Cron Scheduler (Server)';
        } elseif ($is_cli) {
            $enhanced_details['Triggered By'] = 'WP-CLI / Server Process';
        } else {
            $enhanced_details['Triggered By'] = sprintf('Visitor / External Request (%s)', $client_ip);
        }

        // 2. Event Code
        $enhanced_details['Event Code'] = $event_key;

        // 3. Test Mode / Additional Details
        if (isset($incoming_details['test_mode'])) {
            $enhanced_details['Test Mode'] = $incoming_details['test_mode'];
        }

        // Merge any other diagnostic fields passed by caller
        foreach ($incoming_details as $dk => $dv) {
            $normalized_key = ucwords(str_replace('_', ' ', $dk));
            if (!in_array($dk, ['triggered_by', 'event_code', 'test_mode', 'date', 'date_gmt', 'Date', 'Event Code', 'Triggered By', 'Test Mode', 'User Browser Type'], true)) {
                $enhanced_details[$normalized_key] = $dv;
            }
        }

        // 4. Date in GMT
        $enhanced_details['Date'] = $gmt_time;

        // Merge payload defaults
        $full_payload = array_merge([
            'event_key'   => $event_key,
            'title'       => $meta['title'],
            'message'     => $payload['message'] ?? $meta['description'],
            'severity'    => $payload['severity'] ?? $meta['severity'],
            'timestamp'   => time(),
            'datetime'    => $gmt_time,
            'site_name'   => wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES) ?: 'WordPress',
            'site_url'    => get_site_url(),
            'dashboard_url' => admin_url('admin.php?page=webcare-pro-security'),
            'notifications_url' => admin_url('admin.php?page=webcare-pro-notifications'),
        ], $payload);

        $full_payload['details'] = $enhanced_details;

        $results = [
            'email'   => null,
            'webhook' => null,
        ];

        // 2. Dispatch Email Channel
        if (!empty($event_cfg['email'])) {
            $results['email'] = self::dispatch_email($full_payload);
        }

        // 3. Dispatch Webhook Channel
        if (!empty($event_cfg['webhook'])) {
            $results['webhook'] = self::dispatch_webhooks($full_payload);
        }

        return $results;
    }

    /**
     * Dispatch structured HTML email alert
     */
    private static function dispatch_email(array $payload): bool {
        $settings = SettingsManager::get_settings();
        $to = !empty($settings['alert_emails']) ? $settings['alert_emails'] : get_option('admin_email');
        if (empty($to)) {
            return false;
        }

        $site_name = $payload['site_name'];
        $severity  = strtoupper($payload['severity']);
        $title     = $payload['title'];
        $message   = $payload['message'];
        $time      = $payload['datetime'];
        $site_url  = $payload['site_url'];
        $dash_url  = $payload['dashboard_url'];
        $notif_url = !empty($payload['notifications_url']) ? $payload['notifications_url'] : admin_url('admin.php?page=webcare-pro-notifications');

        // High-density factual subject line for AI parsing
        $host = wp_parse_url($site_url, PHP_URL_HOST) ?: $site_url;
        $subject = sprintf('[%s Alert: %s] %s for %s', $site_name, $severity, $title, $host);

        $severity_color = '#0284c7';
        if ($severity === 'CRITICAL') {
            $severity_color = '#dc2626';
        } elseif ($severity === 'HIGH') {
            $severity_color = '#ea580c';
        } elseif ($severity === 'WARNING') {
            $severity_color = '#d97706';
        }

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: WebCare Pro Security <' . get_option('admin_email') . '>',
        ];

        // Logo URL as requested: siteurl.tld/wp-content/plugins/webcare-pro-security/assets/logo.png
        $logo_url = defined('WEBCAREPROSCAN_URL') ? WEBCAREPROSCAN_URL . 'assets/logo.png' : plugins_url('assets/logo.png', dirname(__DIR__));

        // Gemini AI Overview format (e.g. "WebCare Pro detected an unauthorized plugin deactivation attempt on example.com by user dev2admin.")
        $details = $payload['details'] ?? [];
        $actor   = !empty($details['Triggered By']) ? $details['Triggered By'] : 'system process';
        $ai_overview_summary = sprintf(
            'WebCare Pro triggered a %s security alert (%s) for %s on %s. Triggered by: %s.',
            $severity,
            $title,
            $host,
            $time,
            $actor
        );

        // Build Schema.org / JSON-LD machine-readable envelope for Gmail & Gemini
        $json_ld = [
            '@context'         => 'https://schema.org',
            '@type'            => 'SecurityIncident',
            'name'             => $title,
            'description'      => $ai_overview_summary,
            'disambiguatingDescription' => $message,
            'severity'         => $severity,
            'eventCode'        => $payload['event_key'] ?? 'security_event',
            'datePublished'    => $time,
            'about'            => [
                '@type' => 'WebSite',
                'name'  => $site_name,
                'url'   => $site_url,
            ],
            'publisher'        => [
                '@type' => 'Organization',
                'name'  => 'WebCare Pro',
                'url'   => 'https://webcarespro.com',
            ],
            'diagnosticDetails' => $details,
            'potentialAction'  => [
                '@type'  => 'ViewAction',
                'name'   => 'Open Security Dashboard',
                'target' => $dash_url,
            ],
        ];
        $json_ld_string = wp_json_encode($json_ld, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

        $html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">';
        $html .= '<meta name="description" content="' . esc_attr($ai_overview_summary) . '">';
        $html .= '<meta name="webcare-security-severity" content="' . esc_attr($severity) . '">';
        $html .= '<meta name="webcare-event-code" content="' . esc_attr($payload['event_key'] ?? '') . '">';
        $html .= '<meta name="webcare-site-url" content="' . esc_attr($site_url) . '">';
        $html .= '<script type="application/ld+json">' . $json_ld_string . '</script>';
        $html .= '<style>';
        $html .= '@media only screen and (max-width: 540px) {';
        $html .= '  .webcare-container { width: 100% !important; border-radius: 0 !important; }';
        $html .= '  .webcare-content { padding: 22px 16px !important; }';
        $html .= '  .webcare-header { padding: 24px 18px !important; }';
        $html .= '  .webcare-kv-table { width: 100% !important; }';
        $html .= '  .webcare-kv-row { display: block !important; width: 100% !important; padding: 10px 14px !important; box-sizing: border-box !important; }';
        $html .= '  .webcare-kv-label { display: block !important; width: 100% !important; padding: 0 0 4px 0 !important; font-size: 11px !important; }';
        $html .= '  .webcare-kv-val { display: block !important; width: 100% !important; padding: 0 !important; font-size: 12.5px !important; word-break: break-word !important; }';
        $html .= '  .webcare-btn { display: block !important; width: 100% !important; box-sizing: border-box !important; text-align: center !important; }';
        $html .= '  .webcare-footer { padding: 22px 18px !important; }';
        $html .= '}';
        $html .= '</style>';
        $html .= '</head><body style="margin: 0; padding: 24px 8px; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; line-height: 1.6; color: #0f172a;">';

        // Hidden AI & Email Client Preheader (Zero visible footprint, ingested by Gemini / Gmail AI)
        $html .= '<div style="display:none;font-size:1px;color:#f1f5f9;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;mso-hide:all;">';
        $html .= esc_html($ai_overview_summary);
        $html .= ' &zwnj;&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;';
        $html .= '</div>';

        $html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #f1f5f9;">';
        $html .= '<tr><td align="center">';
        $html .= '<table role="presentation" class="webcare-container" width="600" cellpadding="0" cellspacing="0" style="max-width: 600px; width: 100%; background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 10px 30px rgba(15, 23, 42, 0.08);">';

        // Top Accent Gradient Bar
        $html .= '<tr><td style="height: 4px; background: linear-gradient(90deg, #4f46e5 0%, #38bdf8 50%, ' . esc_attr($severity_color) . ' 100%);"></td></tr>';

        // Header: Deep Obsidian (#0f172a), high-contrast badges, logo, and title
        $html .= '<tr><td class="webcare-header" style="padding: 30px 32px; background: #0f172a; text-align: left; border-bottom: 3px solid ' . esc_attr($severity_color) . ';">';
        $html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td>';

        // Severity Status Pill Badge
        $badge_bg = 'rgba(59, 130, 246, 0.15)';
        $badge_color = '#60a5fa';
        $badge_border = 'rgba(96, 165, 250, 0.35)';
        $badge_icon = '🛡️';
        if ($severity === 'CRITICAL') {
            $badge_bg = 'rgba(239, 68, 68, 0.18)';
            $badge_color = '#f87171';
            $badge_border = 'rgba(239, 68, 68, 0.4)';
            $badge_icon = '🚨';
        } elseif ($severity === 'HIGH') {
            $badge_bg = 'rgba(249, 115, 22, 0.18)';
            $badge_color = '#fb923c';
            $badge_border = 'rgba(249, 115, 22, 0.4)';
            $badge_icon = '⚠️';
        } elseif ($severity === 'WARNING') {
            $badge_bg = 'rgba(245, 158, 11, 0.18)';
            $badge_color = '#fbbf24';
            $badge_border = 'rgba(245, 158, 11, 0.4)';
            $badge_icon = '⚡';
        }

        $html .= '<div style="display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; letter-spacing: 0.6px; text-transform: uppercase; background: ' . esc_attr($badge_bg) . '; color: ' . esc_attr($badge_color) . '; border: 1px solid ' . esc_attr($badge_border) . '; margin-bottom: 12px;">';
        $html .= $badge_icon . ' ' . esc_html($severity) . ' PRIORITY ALERT';
        $html .= '</div>';

        // Title and Site
        $html .= '<h1 style="margin: 0 0 6px 0; font-size: 20px; font-weight: 800; color: #ffffff; line-height: 1.35;">' . esc_html($title) . '</h1>';
        $html .= '<div style="font-size: 13px; color: #94a3b8;">Target Site: <strong style="color: #38bdf8;">' . esc_html($site_name) . '</strong> (<a href="' . esc_url($site_url) . '" style="color: #38bdf8; text-decoration: none;">' . esc_html($site_url) . '</a>)</div>';
        $html .= '</td></tr></table></td></tr>';

        // Content Body: Clean White Surface
        $html .= '<tr><td class="webcare-content" style="padding: 28px 32px; background: #ffffff;">';

        // AI Summary Quick-Glance Callout (Clean Blue Card)
        $html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; margin-bottom: 20px;">';
        $html .= '<tr><td style="padding: 14px 16px;">';
        $html .= '<div style="font-size: 11px; font-weight: 800; color: #1d4ed8; text-transform: uppercase; letter-spacing: 0.8px; margin-bottom: 4px;">⚡ AI Executive Incident Brief</div>';
        $html .= '<div style="font-size: 13px; color: #1e3a8a; line-height: 1.5; font-weight: 500;">' . esc_html($ai_overview_summary) . '</div>';
        $html .= '</td></tr></table>';

        $html .= '<p style="font-size: 14.5px; color: #334155; margin: 0 0 20px 0; line-height: 1.6;">' . nl2br(esc_html($message)) . '</p>';

        // Diagnostic Details: Clean Matrix (#f8fafc with #e2e8f0 border)
        if (!empty($payload['details']) && is_array($payload['details'])) {
            $html .= '<div style="font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; color: #64748b; margin-bottom: 10px;">Forensic Event Dossier</div>';
            $html .= '<table role="presentation" class="webcare-kv-table" width="100%" cellpadding="0" cellspacing="0" style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; overflow: hidden; margin-bottom: 24px;">';
            $total_items = count($payload['details']);
            $curr = 0;
            foreach ($payload['details'] as $k => $v) {
                $curr++;
                $val = is_scalar($v) ? (string)$v : wp_json_encode($v);
                $is_last = ($curr === $total_items);
                $border_style = $is_last ? '' : 'border-bottom: 1px solid #e2e8f0;';

                $val_color = '#0f172a';
                if (stripos((string)$k, 'code') !== false || stripos((string)$k, 'key') !== false) {
                    $val_color = '#0284c7';
                } elseif (stripos((string)$k, 'status') !== false) {
                    $val_color = '#b45309';
                }

                $html .= '<tr><td style="padding: 12px 16px; ' . $border_style . '" class="webcare-kv-row">';
                $html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>';
                $html .= '<td width="35%" class="webcare-kv-label" style="font-size: 12px; color: #64748b; font-weight: 600; vertical-align: top;">' . esc_html(ucwords(str_replace('_', ' ', (string)$k))) . '</td>';
                $html .= '<td width="65%" class="webcare-kv-val" style="font-size: 13px; color: ' . esc_attr($val_color) . '; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; word-break: break-all; vertical-align: top;">' . esc_html((string)$val) . '</td>';
                $html .= '</tr></table></td></tr>';
            }
            $html .= '</table>';
        }

        // Action CTA Button
        $html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top: 24px;">';
        $html .= '<tr><td align="center">';
        $html .= '<a href="' . esc_url($dash_url) . '" class="webcare-btn" style="display: inline-block; background: #4f46e5; color: #ffffff; font-size: 14px; font-weight: 700; text-decoration: none; padding: 14px 32px; border-radius: 8px; box-shadow: 0 4px 16px rgba(79, 70, 229, 0.4);">';
        $html .= 'Open WebCare Pro Security Dashboard &rarr;';
        $html .= '</a></td></tr></table>';

        $html .= '</td></tr>';

        // Sleek Dark Footer matching exact requested screenshot format
        $html .= '<tr><td class="webcare-footer" style="background: #0b1120; padding: 28px 32px; border-top: 1px solid rgba(255, 255, 255, 0.08); font-size: 12.5px; color: #94a3b8; line-height: 1.6;">';
        $html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td>';
        $html .= '<div style="margin-bottom: 12px;">';
        $html .= '<strong style="color: #ffffff; font-size: 14px; letter-spacing: 0.2px;">About WebCare Pro</strong>';
        $html .= '<span style="color: #475569; margin: 0 8px;">•</span>';
        $html .= '<a href="https://webcarespro.com" target="_blank" style="color: #38bdf8; text-decoration: none; font-weight: 600;">https://webcarespro.com</a>';
        $html .= '</div>';
        $html .= '<p style="margin: 0 0 16px 0; color: #cbd5e1; font-size: 12.5px; line-height: 1.6;">';
        $html .= 'Mir Alamin (WebCare Pro) helps businesses build, secure, optimize, and manage high-performance websites and servers. From Linux &amp; cloud infrastructure to blazing-fast performance, website security, migrations, Cloudflare, DNS, managed hosting, and modern web development—keeping your online presence fast, secure, and always available.';
        $html .= '</p>';
        $html .= '<div style="border-top: 1px solid rgba(255, 255, 255, 0.08); padding-top: 14px; font-size: 12px; color: #94a3b8; text-align: left; line-height: 1.6;">';
        $plugin_ver_str = defined('WEBCAREPROSCAN_VERSION') ? 'v' . WEBCAREPROSCAN_VERSION : 'v2.9.0';
        $html .= 'Dispatched by WebCare Pro Security &amp; Firewall <strong style="color: #38bdf8;">' . esc_html($plugin_ver_str) . '</strong> on <strong style="color: #ffffff;">' . esc_html($time) . '</strong>. You can manage granular notification preferences anytime under <strong>WebCare Pro &gt; <a href="' . esc_url($notif_url) . '" style="color: #38bdf8; text-decoration: underline;">Notifications</a></strong>.';
        $html .= '</div></td></tr></table></td></tr>';

        $html .= '</table></td></tr></table></body></html>';

        try {
            return (bool) wp_mail($to, $subject, $html, $headers);
        } catch (\Throwable $e) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
            error_log('WebCare Pro: wp_mail failed due to mailer engine error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Dispatch structured payload across configured DevSecOps webhooks
     */
    private static function dispatch_webhooks(array $payload): bool {
        $settings = SettingsManager::get_settings();
        $has_slack   = !empty($settings['slack_enabled']) && !empty($settings['slack_webhook_url']);
        $has_discord = !empty($settings['discord_enabled']) && !empty($settings['discord_webhook_url']);
        $has_clickup = !empty($settings['clickup_enabled']) && !empty($settings['clickup_webhook_url']);
        $has_asana   = !empty($settings['asana_enabled']) && !empty($settings['asana_webhook_url']);
        $has_generic = !empty($settings['generic_webhook_enabled']) && !empty($settings['generic_webhook_url']);

        if (!$has_slack && !$has_discord && !$has_clickup && !$has_asana && !$has_generic) {
            return false;
        }

        $severity  = strtolower($payload['severity']);
        $site_name = $payload['site_name'];
        $site_url  = $payload['site_url'];
        $title     = $payload['title'];
        $message   = $payload['message'];
        $dash_url  = $payload['dashboard_url'];

        $is_danger = ($severity === 'critical' || $severity === 'high');
        $color_hex = $is_danger ? WebhookService::COLOR_CRITICAL : WebhookService::COLOR_INFO;
        $color_int = $is_danger ? 14428198 : 164999;
        $status_emoji = $severity === 'critical' ? '🚨' : ($severity === 'high' ? '⚠️' : '🛡️');

        // 1. Slack
        if ($has_slack) {
            $slack_payload = [
                'text' => "{$status_emoji} [{$payload['severity']}] {$title} on {$site_name}",
                'attachments' => [
                    [
                        'color' => $color_hex,
                        'blocks' => [
                            [
                                'type' => 'header',
                                'text' => ['type' => 'plain_text', 'text' => "{$status_emoji} {$title}", 'emoji' => true]
                            ],
                            [
                                'type' => 'section',
                                'text' => [
                                    'type' => 'mrkdwn',
                                    'text' => "*Site:* <{$site_url}|{$site_name}>\n*Severity:* `{$payload['severity']}`\n*Details:* {$message}"
                                ]
                            ],
                            [
                                'type' => 'actions',
                                'elements' => [
                                    [
                                        'type' => 'button',
                                        'text' => ['type' => 'plain_text', 'text' => 'Review Incident in Dashboard'],
                                        'url' => $dash_url,
                                        'style' => $is_danger ? 'danger' : 'primary'
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ];
            self::post_webhook_direct($settings['slack_webhook_url'], $slack_payload);
        }

        // 2. Discord
        if ($has_discord) {
            $discord_payload = [
                'username' => 'WebCare Pro Security Sentinel',
                'embeds' => [
                    [
                        'title' => "{$status_emoji} {$title}",
                        'description' => $message,
                        'url' => $dash_url,
                        'color' => $color_int,
                        'fields' => [
                            ['name' => 'Site', 'value' => $site_name, 'inline' => true],
                            ['name' => 'Severity', 'value' => strtoupper($payload['severity']), 'inline' => true],
                            ['name' => 'Engine Version', 'value' => 'v' . (defined('WEBCAREPROSCAN_VERSION') ? WEBCAREPROSCAN_VERSION : '2.7.1'), 'inline' => true],
                            ['name' => 'Event Key', 'value' => $payload['event_key'], 'inline' => true],
                        ],
                        'footer' => ['text' => 'WebCare Pro Security Notifications'],
                        'timestamp' => gmdate('Y-m-d\TH:i:s\Z'),
                    ]
                ]
            ];
            self::post_webhook_direct($settings['discord_webhook_url'], $discord_payload);
        }

        // 3. ClickUp
        if ($has_clickup) {
            $clickup_payload = [
                'name'        => "{$status_emoji} [{$payload['severity']}] {$title} - {$site_name}",
                'content'     => "{$message}\n\n- Site: {$site_name} ({$site_url})\n- Security Dashboard: {$dash_url}",
                'priority'    => $is_danger ? 1 : 3,
                'tags'        => ['security', 'webcare-pro-security', $payload['event_key']],
                'event'       => $payload['event_key'],
                'site_name'   => $site_name,
            ];
            self::post_webhook_direct($settings['clickup_webhook_url'], $clickup_payload);
        }

        // 4. Asana
        if ($has_asana) {
            $asana_payload = [
                'name'  => "{$status_emoji} [{$payload['severity']}] {$title} - {$site_name}",
                'notes' => "{$message}\n\nSite: {$site_name} ({$site_url})\nDashboard: {$dash_url}",
                'data'  => [
                    'name'  => "{$status_emoji} [{$payload['severity']}] {$title} - {$site_name}",
                    'notes' => "{$message}\n\nSite: {$site_name} ({$site_url})\nDashboard: {$dash_url}",
                ],
            ];
            self::post_webhook_direct($settings['asana_webhook_url'], $asana_payload);
        }

        // 5. Generic Automation Webhook
        if ($has_generic) {
            $generic_payload = [
                'event'         => $payload['event_key'],
                'title'         => $title,
                'message'       => $message,
                'severity'      => $payload['severity'],
                'site_name'     => $site_name,
                'site_url'      => $site_url,
                'dashboard_url' => $dash_url,
                'timestamp'     => $payload['timestamp'],
                'datetime'      => $payload['datetime'],
                'details'       => $payload['details'] ?? [],
            ];
            self::post_webhook_direct($settings['generic_webhook_url'], $generic_payload);
        }

        return true;
    }

    /**
     * Send HTTP POST to a webhook endpoint
     */
    private static function post_webhook_direct(string $url, array $payload): bool {
        if (empty($url)) {
            return false;
        }
        $resp = wp_remote_post($url, [
            'timeout'     => 8,
            'blocking'    => false, // Non-blocking async dispatch for maximum performance
            'headers'     => ['Content-Type' => 'application/json'],
            'body'        => wp_json_encode($payload),
            'data_format' => 'body',
        ]);
        if (is_wp_error($resp)) {
            if ($payload['event_key'] !== 'webhook_delivery_failed') {
                self::trigger('webhook_delivery_failed', [
                    'severity' => 'warning',
                    /* translators: 1: webhook endpoint URL, 2: error message */
                    'message'  => sprintf(__('Webhook delivery failed to destination "%1$s": %2$s', 'webcare-pro-security'), esc_url($url), $resp->get_error_message()),
                    'details'  => [
                        'Destination URL' => esc_url($url),
                        'Failed Event'    => $payload['event_key'] ?? 'unknown',
                        'Error Message'   => $resp->get_error_message(),
                    ],
                ]);
            }
            return false;
        }
        return true;
    }
}
