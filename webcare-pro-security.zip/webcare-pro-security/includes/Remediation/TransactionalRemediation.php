<?php
namespace WebCareProScanner\Remediation;

use WebCareProScanner\Filesystem\PathValidator;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * TransactionalRemediation
 *
 * Implements atomic, multi-threat remediation transactions with 1-click safe rollback.
 * Captures pre-remediation byte-for-byte file snapshots, database states, and cron entries
 * prior to executing any destructive quarantine or disinfection operations.
 */
class TransactionalRemediation {

    /**
     * Get root directory for transaction manifests and snapshots.
     *
     * @return string
     */
    public static function get_transactions_dir(): string {
        $upload_dir = wp_upload_dir();
        $base = wp_normalize_path($upload_dir['basedir'] . '/webcare-pro-security/.remediation/transactions');

        if (!is_dir($base)) {
            wp_mkdir_p($base);
            // Harden transaction storage against public web access (Apache 2.2 + 2.4 mod_authz_core compatibility)
            @file_put_contents($base . '/.htaccess', "<IfModule !mod_authz_core.c>\nOrder Deny,Allow\nDeny from all\n</IfModule>\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>");
            @file_put_contents($base . '/index.php', "<?php\nhttp_response_code(403);\nexit('Direct access forbidden.');\n");
        }

        return $base;
    }

    /**
     * Validate transaction ID format to prevent path traversal
     */
    public static function sanitize_tx_id(string $tx_id): string {
        $clean = preg_replace('/[^a-zA-Z0-9_-]/', '', $tx_id);
        return (preg_match('/^tx_[0-9]{8}_[0-9]{6}_[a-zA-Z0-9]+$/', $clean)) ? $clean : '';
    }

    /**
     * Start a new atomic remediation transaction.
     *
     * @param string $title
     * @param string $reason
     * @param array $context
     * @return string Transaction ID
     */
    public static function start_transaction(string $title, string $reason = '', array $context = []): string {
        $base_dir = self::get_transactions_dir();
        $tx_id = 'tx_' . gmdate('Ymd_His') . '_' . bin2hex(random_bytes(4));
        $tx_dir = $base_dir . '/' . $tx_id;

        wp_mkdir_p($tx_dir . '/files');

        $user = wp_get_current_user();
        $author = ($user && $user->exists()) ? $user->user_login : 'admin';

        $manifest = [
            'tx_id'       => $tx_id,
            'title'       => sanitize_text_field($title),
            'reason'      => sanitize_textarea_field($reason ?: 'Multi-threat attack chain eradication'),
            'status'      => 'in_progress',
            'created_at'  => current_time('mysql'),
            'timestamp'   => time(),
            'created_by'  => $author,
            'context'     => $context,
            'items'       => [],
        ];

        file_put_contents($tx_dir . '/manifest.json', wp_json_encode($manifest, JSON_PRETTY_PRINT));

        return $tx_id;
    }

    /**
     * Record a pre-remediation file snapshot in the transaction vault.
     *
     * @param string $tx_id
     * @param string $file_path
     * @param string $action_type 'quarantine' | 'delete' | 'repair' | 'permission_fix'
     * @param int|null $issue_id
     * @return bool
     */
    public static function record_file_snapshot(string $tx_id, string $file_path, string $action_type = 'quarantine', ?int $issue_id = null): bool {
        $tx_id = self::sanitize_tx_id($tx_id);
        if (empty($tx_id)) {
            return false;
        }

        $tx_dir = self::get_transactions_dir() . '/' . $tx_id;
        $manifest_file = $tx_dir . '/manifest.json';

        if (!file_exists($manifest_file)) {
            return false;
        }

        $manifest = json_decode(file_get_contents($manifest_file), true);
        if (!is_array($manifest)) {
            return false;
        }

        $clean_path = ltrim(str_replace(['../', '..\\'], '', $file_path), '/\\');
        $candidate  = file_exists(ABSPATH . $clean_path) ? (ABSPATH . $clean_path) : $file_path;

        if (!is_string($candidate) || $candidate === '' || is_link($candidate)) {
            return false;
        }

        $real_path = realpath($candidate);
        if ($real_path === false || !is_file($real_path)) {
            return false;
        }

        $full_path = wp_normalize_path($real_path);
        if (!\WebCareProScanner\Filesystem\PathValidator::is_inside_root($full_path, ABSPATH, false)) {
            return false;
        }

        $protected_basenames = ['wp-config.php', '.htaccess', '.user.ini', 'php.ini', '.env'];
        if (in_array(strtolower(basename($full_path)), $protected_basenames, true)) {
            return false;
        }

        $backup_key  = 'f_' . count($manifest['items']) . '_' . basename($full_path) . '.bak.php';
        $backup_path = $tx_dir . '/files/' . $backup_key;

        // Perform chunked streaming AEAD encryption into transaction vault
        $v_res = \WebCareProScanner\Security\SecretVault::encrypt_file_to_vault($full_path, $backup_path);
        if (empty($v_res['success'])) {
            return false;
        }

        if (!file_exists($backup_path) || filesize($backup_path) === 0) {
            if (file_exists($backup_path)) {
                wp_delete_file($backup_path);
            }
            return false;
        }

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod
        @chmod($backup_path, 0600);

        $rel_path = ltrim(str_replace(wp_normalize_path(ABSPATH), '', $full_path), '/');

        $manifest['items'][] = [
            'type'            => 'file',
            'action'          => $action_type,
            'target_path'     => $rel_path,
            'original_abs'    => $full_path,
            'backup_filename' => $backup_key,
            'original_hash'   => hash_file('sha256', $full_path),
            'original_perms'  => substr(sprintf('%o', fileperms($full_path)), -4),
            'original_mtime'  => @filemtime($full_path) ?: time(),
            'issue_id'        => $issue_id,
            'timestamp'       => time(),
        ];

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        if (@file_put_contents($manifest_file, wp_json_encode($manifest, JSON_PRETTY_PRINT), LOCK_EX) === false) {
            wp_delete_file($backup_path);
            return false;
        }
        return true;
    }

    /**
     * Record a pre-remediation database row snapshot.
     *
     * @param string $tx_id
     * @param string $table_name
     * @param string $primary_key
     * @param mixed $row_id
     * @param array $original_row
     * @param int|null $issue_id
     * @return bool
     */
    public static function record_db_snapshot(string $tx_id, string $table_name, string $primary_key, $row_id, array $original_row, ?int $issue_id = null): bool {
        $tx_id = self::sanitize_tx_id($tx_id);
        if (empty($tx_id)) {
            return false;
        }

        $tx_dir = self::get_transactions_dir() . '/' . $tx_id;
        $manifest_file = $tx_dir . '/manifest.json';

        if (!file_exists($manifest_file)) {
            return false;
        }

        $manifest = json_decode(file_get_contents($manifest_file), true);
        if (!is_array($manifest)) {
            return false;
        }

        $manifest['items'][] = [
            'type'          => 'database',
            'table_name'    => sanitize_text_field($table_name),
            'primary_key'   => sanitize_key($primary_key),
            'row_id'        => $row_id,
            'original_data' => $original_row,
            'issue_id'      => $issue_id,
            'timestamp'     => time(),
        ];

        file_put_contents($manifest_file, wp_json_encode($manifest, JSON_PRETTY_PRINT));
        return true;
    }

    /**
     * Record a pre-remediation user account snapshot in the transaction vault.
     *
     * @param string $tx_id
     * @param int $user_id
     * @param string $backup_filename
     * @param string $action_type 'delete' | 'demote'
     * @return bool
     */
    public static function record_user_snapshot(string $tx_id, int $user_id, string $backup_filename, string $action_type = 'delete'): bool {
        $tx_id = self::sanitize_tx_id($tx_id);
        if (empty($tx_id)) {
            return false;
        }

        $tx_dir = self::get_transactions_dir() . '/' . $tx_id;
        $manifest_file = $tx_dir . '/manifest.json';

        if (!file_exists($manifest_file)) {
            return false;
        }

        $manifest = json_decode(file_get_contents($manifest_file), true);
        if (!is_array($manifest)) {
            return false;
        }

        $manifest['items'][] = [
            'type'            => 'user',
            'action_type'     => $action_type,
            'user_id'         => $user_id,
            'backup_filename' => $backup_filename,
            'target_path'     => "wp_users:user_id_{$user_id}",
            'timestamp'       => time(),
        ];

        file_put_contents($manifest_file, wp_json_encode($manifest, JSON_PRETTY_PRINT));
        return true;
    }

    /**
     * Commit and finalize transaction after all steps have succeeded.
     *
     * @param string $tx_id
     * @return array
     */
    public static function commit_transaction(string $tx_id): array {
        $tx_id = self::sanitize_tx_id($tx_id);
        if (empty($tx_id)) {
            return ['success' => false, 'message' => __('Invalid transaction ID.', 'webcare-pro-security')];
        }

        $tx_dir = self::get_transactions_dir() . '/' . $tx_id;
        $manifest_file = $tx_dir . '/manifest.json';

        if (!file_exists($manifest_file)) {
            return ['success' => false, 'message' => 'Transaction not found.'];
        }

        $manifest = json_decode(file_get_contents($manifest_file), true);
        if (!is_array($manifest)) {
            return ['success' => false, 'message' => 'Invalid transaction manifest.'];
        }

        $manifest['status'] = 'completed';
        $manifest['committed_at'] = current_time('mysql');
        $manifest['total_items'] = count($manifest['items']);

        file_put_contents($manifest_file, wp_json_encode($manifest, JSON_PRETTY_PRINT));

        // Post-Fix Store & Checkout Pulse Check
        $pulse = class_exists('\\WebCareProScanner\\System\\PulseHealthCheck')
            ? \WebCareProScanner\System\PulseHealthCheck::check_store_pulse()
            : ['all_passed' => true, 'summary' => ''];

        // If any critical endpoint failed, automatically trigger safety rollback
        if (!$pulse['all_passed']) {
            self::rollback_transaction($tx_id);
            return [
                'success'        => false,
                'rollback'       => true,
                'tx_id'          => $tx_id,
                'items_count'    => $manifest['total_items'],
                'pulse'          => $pulse,
                'message'        => __('Safety Rollback Triggered: A 500 error or site conflict was detected immediately following remediation. Your files were automatically restored to their original state.', 'webcare-pro-security'),
            ];
        }

        return [
            'success'     => true,
            'tx_id'       => $tx_id,
            'items_count' => $manifest['total_items'],
            'pulse'       => $pulse,
            /* translators: 1: transaction ID, 2: number of items */
            'message'     => sprintf(__('Remediation transaction %1$s committed with %2$d items snapshotted.', 'webcare-pro-security'), $tx_id, $manifest['total_items']),
        ];
    }

    /**
     * 1-Click Rollback: Atomically restore all files, database states, and issues from a transaction.
     *
     * @param string $tx_id
     * @return array
     */
    public static function rollback_transaction(string $tx_id): array {
        $tx_id = self::sanitize_tx_id($tx_id);
        if (empty($tx_id)) {
            return ['success' => false, 'message' => __('Invalid transaction ID.', 'webcare-pro-security')];
        }

        $tx_dir = self::get_transactions_dir() . '/' . $tx_id;
        $manifest_file = $tx_dir . '/manifest.json';

        if (!file_exists($manifest_file)) {
            return ['success' => false, 'message' => __('Transaction manifest not found.', 'webcare-pro-security')];
        }

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        $lock_fp = @fopen($manifest_file, 'r+');
        if (!$lock_fp) {
            return ['success' => false, 'message' => __('Cannot acquire transaction file handle.', 'webcare-pro-security')];
        }

        if (!@flock($lock_fp, LOCK_EX)) {
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
            fclose($lock_fp);
            return ['success' => false, 'message' => __('Cannot acquire transaction lock.', 'webcare-pro-security')];
        }

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread
        $raw_manifest = stream_get_contents($lock_fp);
        $manifest = json_decode((string) $raw_manifest, true);
        if (!is_array($manifest)) {
            flock($lock_fp, LOCK_UN);
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
            fclose($lock_fp);
            return ['success' => false, 'message' => __('Corrupt transaction manifest.', 'webcare-pro-security')];
        }

        $user_mgr = new \WebCareProScanner\WordPress\UserRemediationManager();
        $missing_users = $user_mgr->get_missing_user_backups();

        if (($manifest['status'] ?? '') === 'rolled_back' && empty($missing_users)) {
            flock($lock_fp, LOCK_UN);
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
            fclose($lock_fp);
            return ['success' => false, 'message' => __('This transaction was already rolled back.', 'webcare-pro-security')];
        }

        if (($manifest['status'] ?? '') === 'rollback_applying') {
            flock($lock_fp, LOCK_UN);
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
            fclose($lock_fp);
            return ['success' => false, 'message' => __('A rollback is already currently in progress for this transaction.', 'webcare-pro-security')];
        }

        // Set status to rollback_applying atomically inside exclusive file lock (Finding 2.2)
        $manifest['status'] = 'rollback_applying';
        fseek($lock_fp, 0);
        ftruncate($lock_fp, 0);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
        fwrite($lock_fp, (string) wp_json_encode($manifest, JSON_PRETTY_PRINT));
        fflush($lock_fp);

        global $wpdb;
        $restored_files = 0;
        $restored_db    = 0;
        $restored_users = 0;
        $errors         = [];

        // Reverse through items so latest changes roll back first
        $items = array_reverse($manifest['items'] ?? []);
        $restored_uids = [];

        foreach ($items as $item) {
            $type = $item['type'] ?? '';

            if ($type === 'file') {
                $target_abs  = $item['original_abs'] ?? '';
                $backup_file = $tx_dir . '/files/' . ($item['backup_filename'] ?? '');

                if (!\WebCareProScanner\Filesystem\PathValidator::is_safe_write_target($target_abs, ABSPATH)) {
                    $errors[] = sprintf('Refusing rollback write outside ABSPATH boundary for file: %s', esc_html($target_abs));
                    continue;
                }

                if (!file_exists($backup_file)) {
                    $errors[] = sprintf('Backup file missing from transaction vault: %s', esc_html($item['backup_filename'] ?? ''));
                    continue;
                }

                // Ensure directory exists
                $dir = dirname($target_abs);
                if (!is_dir($dir)) {
                    wp_mkdir_p($dir);
                }

                // Decrypt backup to a temporary file
                $temp_restore = $target_abs . '.webcare_rst_tmp_' . bin2hex(random_bytes(6));
                $dec_res = \WebCareProScanner\Security\SecretVault::decrypt_vault_to_file($backup_file, $temp_restore, null, true);
                if (empty($dec_res['success'])) {
                    if (file_exists($temp_restore)) {
                        wp_delete_file($temp_restore);
                    }
                    $errors[] = sprintf('Cryptographic decryption failed for %s: %s', basename($target_abs), $dec_res['error'] ?? 'Corrupt vault file');
                    continue;
                }

                // Verify original hash before moving into place
                if (!empty($item['original_hash'])) {
                    $restored_hash = @hash_file('sha256', $temp_restore);
                    if (!hash_equals((string) $item['original_hash'], (string) $restored_hash)) {
                        wp_delete_file($temp_restore);
                        $errors[] = sprintf('Integrity verification failed for %s: restored hash does not match original snapshot.', basename($target_abs));
                        continue;
                    }
                }

                // Atomically move restored file into place
                // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- Atomic move of staging file
                if (!@rename($temp_restore, $target_abs)) {
                    // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_copy -- Fallback copy when rename across filesystems fails
                    if (!@copy($temp_restore, $target_abs)) {
                        wp_delete_file($temp_restore);
                        /* translators: %s: Base filename of the target file being restored */
                        $errors[] = sprintf(__('Failed to restore file: %s', 'webcare-pro-security'), basename($target_abs));
                        continue;
                    }
                    wp_delete_file($temp_restore);
                }

                $restored_files++;
                // Restore original permissions & timestamps
                if (!empty($item['original_perms'])) {
                    global $wp_filesystem;
                    if ($wp_filesystem && method_exists($wp_filesystem, 'chmod')) {
                        $wp_filesystem->chmod($target_abs, octdec($item['original_perms']));
                    } else {
                        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod
                        @chmod($target_abs, octdec($item['original_perms']));
                    }
                }
                if (!empty($item['original_mtime'])) {
                    global $wp_filesystem;
                    if ($wp_filesystem && method_exists($wp_filesystem, 'touch')) {
                        $wp_filesystem->touch($target_abs, (int) $item['original_mtime']);
                    } else {
                        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_touch
                        @touch($target_abs, (int) $item['original_mtime']);
                    }
                }

                // Re-open scan issue
                if (!empty($item['issue_id'])) {
                    $table_issues = $wpdb->prefix . 'webcareproscan_scan_issues';
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $wpdb->update($table_issues, ['status' => 'open'], ['id' => (int) $item['issue_id']]);
                }
            } elseif ($type === 'database') {
                $table = $item['table_name'] ?? '';
                $pkey  = $item['primary_key'] ?? 'id';
                $rid   = $item['row_id'] ?? null;
                $data  = $item['original_data'] ?? [];

                if ($table && $rid !== null && !empty($data)) {
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $updated = $wpdb->update($table, $data, [$pkey => $rid]);
                    if ($updated !== false) {
                        $restored_db++;
                    }
                }

                // Re-open scan issue
                if (!empty($item['issue_id'])) {
                    $table_issues = $wpdb->prefix . 'webcareproscan_scan_issues';
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $wpdb->update($table_issues, ['status' => 'open'], ['id' => (int) $item['issue_id']]);
                }
            } elseif ($type === 'user') {
                $backup_file = $item['backup_filename'] ?? '';
                if ($backup_file) {
                    $user_mgr = new \WebCareProScanner\WordPress\UserRemediationManager();
                    $u_res = $user_mgr->restore_user($backup_file);
                    if ($u_res['success']) {
                        $restored_users++;
                        if (!empty($u_res['user_id'])) {
                            $restored_uids[] = (int) $u_res['user_id'];
                        }
                    } else {
                        /* translators: 1: user ID, 2: error message */
                        $errors[] = sprintf(__('Failed to restore user #%1$d: %2$s', 'webcare-pro-security'), (int) ($item['user_id'] ?? 0), $u_res['error'] ?? '');
                    }
                }
            }
        }

        // Correlated user recovery fallback:
        // If this transaction was an attack chain eradication that preceded explicit user snapshot tracking,
        // recover any user backups created during this transaction's execution window.
        $tx_time = (int) ($manifest['timestamp'] ?? 0);
        if ($tx_time > 0) {
            $user_mgr = new \WebCareProScanner\WordPress\UserRemediationManager();
            $available_user_backups = $user_mgr->list_user_backups();
            foreach ($available_user_backups as $ub) {
                $uid = (int) $ub['user_id'];
                if (in_array($uid, $restored_uids, true)) {
                    continue;
                }
                // Check if user backup was created within 10 minutes of this transaction
                if (abs($ub['timestamp'] - $tx_time) <= 600) {
                    $u_res = $user_mgr->restore_user($ub['backup_file']);
                    if ($u_res['success']) {
                        $restored_users++;
                        $restored_uids[] = $uid;
                    }
                }
            }
        }

        $user = wp_get_current_user();
        $author = ($user && $user->exists()) ? $user->user_login : 'admin';

        $manifest['status']         = empty($errors) ? 'rolled_back' : 'rollback_partial_failure';
        $manifest['rolled_back_at'] = current_time('mysql');
        $manifest['rolled_back_by'] = $author;
        if (!empty($errors)) {
            $manifest['rollback_errors'] = $errors;
        }

        fseek($lock_fp, 0);
        ftruncate($lock_fp, 0);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
        fwrite($lock_fp, (string) wp_json_encode($manifest, JSON_PRETTY_PRINT));
        fflush($lock_fp);
        flock($lock_fp, LOCK_UN);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        fclose($lock_fp);

        $msg_parts = [];
        /* translators: %d: number of files */
        if ($restored_files > 0) $msg_parts[] = sprintf(__('%d file(s)', 'webcare-pro-security'), $restored_files);
        /* translators: %d: number of database records */
        if ($restored_db > 0)    $msg_parts[] = sprintf(__('%d database record(s)', 'webcare-pro-security'), $restored_db);
        /* translators: %d: number of user accounts */
        if ($restored_users > 0) $msg_parts[] = sprintf(__('%d user account(s)', 'webcare-pro-security'), $restored_users);

        $restored_summary = !empty($msg_parts) ? implode(', ', $msg_parts) : __('0 items', 'webcare-pro-security');

        if (class_exists('\\WebCareProScanner\\Notifications\\NotificationDispatcher')) {
            \WebCareProScanner\Notifications\NotificationDispatcher::trigger('remediation_transaction_rollback', [
                'severity' => 'warning',
                /* translators: 1: transaction ID, 2: restored summary details */
                'message'  => sprintf(__('Remediation transaction %1$s reverted: restored %2$s.', 'webcare-pro-security'), $tx_id, $restored_summary),
                'details'  => [
                    'Transaction ID'  => $tx_id,
                    'Restored Files'  => $restored_files,
                    'Restored DB'     => $restored_db,
                    'Restored Users'  => $restored_users,
                    'Rolled Back By'  => $author,
                ],
            ]);
        }

        return [
            'success'        => empty($errors),
            'tx_id'          => $tx_id,
            'restored_files' => $restored_files,
            'restored_db'    => $restored_db,
            'restored_users' => $restored_users,
            'errors'         => $errors,
            'message'        => sprintf(
                /* translators: 1: transaction ID, 2: restored summary details */
                __('Transaction %1$s rolled back successfully: restored %2$s.', 'webcare-pro-security'),
                $tx_id,
                $restored_summary
            ),
        ];
    }

    /**
     * Retrieve all remediation transactions.
     *
     * @param int $limit
     * @return array
     */
    public static function list_transactions(int $limit = 30): array {
        $base_dir = self::get_transactions_dir();
        if (!is_dir($base_dir)) {
            return [];
        }

        $dirs = @scandir($base_dir) ?: [];
        $transactions = [];

        foreach ($dirs as $d) {
            if ($d === '.' || $d === '..' || !str_starts_with($d, 'tx_')) {
                continue;
            }

            $manifest_file = $base_dir . '/' . $d . '/manifest.json';
            if (!file_exists($manifest_file)) {
                continue;
            }

            $manifest = json_decode(file_get_contents($manifest_file), true);
            if (is_array($manifest)) {
                $file_items = array_filter($manifest['items'] ?? [], fn($i) => ($i['type'] ?? '') === 'file');
                $db_items   = array_filter($manifest['items'] ?? [], fn($i) => ($i['type'] ?? '') === 'database');
                $user_items = array_filter($manifest['items'] ?? [], fn($i) => ($i['type'] ?? '') === 'user');

                $transactions[] = [
                    'tx_id'          => $manifest['tx_id'] ?? $d,
                    'title'          => $manifest['title'] ?? 'Attack Chain Eradication',
                    'reason'         => $manifest['reason'] ?? '',
                    'status'         => $manifest['status'] ?? 'completed',
                    'created_at'     => $manifest['created_at'] ?? '',
                    'timestamp'      => $manifest['timestamp'] ?? 0,
                    'created_by'     => $manifest['created_by'] ?? 'admin',
                    'files_count'    => count($file_items),
                    'db_count'       => count($db_items),
                    'users_count'    => count($user_items),
                    'total_items'    => count($manifest['items'] ?? []),
                    'rolled_back_at' => $manifest['rolled_back_at'] ?? null,
                    'rolled_back_by' => $manifest['rolled_back_by'] ?? null,
                    'sample_targets' => array_slice(array_column($file_items, 'target_path'), 0, 3),
                ];
            }
        }

        // Sort descending by timestamp
        usort($transactions, fn($a, $b) => ($b['timestamp'] ?? 0) <=> ($a['timestamp'] ?? 0));

        return array_slice($transactions, 0, $limit);
    }

    /**
     * Execute surgical restoration of a compromised file with automatic CrashGuard rollback.
     * Restores modified files from their compressed FimVaultManager baseline, avoiding destructive quarantines.
     *
     * @param string $absolute_path
     * @return bool
     */
    public static function surgically_repair_file(string $absolute_path): bool {
        if (!file_exists($absolute_path)) {
            return false;
        }

        // 1. Snapshot current corrupted state for emergency rollback
        $corrupted_backup = sys_get_temp_dir() . '/webcare_rollback_' . md5($absolute_path) . '.tmp';
        @copy($absolute_path, $corrupted_backup);

        // 2. Attempt surgical restoration from vault baseline
        $restored = false;
        if (class_exists('\\WebCareProScanner\\Integrity\\FimVaultManager')) {
            $restored = \WebCareProScanner\Integrity\FimVaultManager::restore_from_baseline($absolute_path);
        }

        if (!$restored) {
            wp_delete_file($corrupted_backup);
            return false;
        }

        // 3. Verify site stability using CrashGuard circuit breaker if available
        if (class_exists('\\WebCareProScanner\\System\\CrashGuard') && method_exists('\\WebCareProScanner\\System\\CrashGuard', 'verify_site_health_probe')) {
            $healthy = \WebCareProScanner\System\CrashGuard::verify_site_health_probe();
            if (!$healthy) {
                // Rollback to corrupted state if restoration triggers a fatal error
                @copy($corrupted_backup, $absolute_path);
                wp_delete_file($corrupted_backup);
                return false;
            }
        }

        wp_delete_file($corrupted_backup);
        return true;
    }
}
