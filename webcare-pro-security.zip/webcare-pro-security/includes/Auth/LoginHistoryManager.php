<?php
namespace WebCareProScanner\Auth;

use WebCareProScanner\Security\SecretVault;
use WebCareProScanner\Firewall\FirewallEngine;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * LoginHistoryManager
 *
 * Tracks, logs, and forensics-audits administrator authentication sessions.
 * ENCRYPTION GUARANTEE: All sensitive telemetry (IP, User-Agent, Screen Resolution,
 * Viewport, Timezone, Device Type) is encrypted at rest using AES-256-GCM AEAD
 * via SecretVault before writing to the database. Zero plaintext in MySQL.
 */
class LoginHistoryManager {

    const TABLE_NAME = 'webcareproscan_login_history';

    private static $last_auth_token = '';

    /**
     * Bootstrap Login History tracking hooks
     */
    public static function init() {
        // Capture generated session token during auth cookie issuance
        add_action('set_auth_cookie', [__CLASS__, 'on_set_auth_cookie'], 10, 6);

        // Inject lightweight screen detection into standard WordPress login form
        add_action('login_form', [__CLASS__, 'render_login_screen_detector']);
        add_action('login_enqueue_scripts', [__CLASS__, 'enqueue_login_screen_detector']);

        // Record session upon login
        add_action('wp_login', [__CLASS__, 'on_user_login'], 25, 2);

        // Record logout timestamp
        add_action('wp_logout', [__CLASS__, 'on_user_logout']);
    }

    /**
     * Cache the freshly minted session token from WordPress core's set_auth_cookie hook
     */
    public static function on_set_auth_cookie($auth_cookie, $expire, $expiration, $user_id, $scheme, $token) {
        self::$last_auth_token = (string) $token;
    }

    /**
     * Inject screen size detector hidden inputs into login form
     */
    public static function render_login_screen_detector() {
        echo '<input type="hidden" name="webcareproscan_screen_res" id="webcareproscan_screen_res" value="">' . "\n";
        echo '<input type="hidden" name="webcareproscan_client_tz" id="webcareproscan_client_tz" value="">' . "\n";
    }

    /**
     * Enqueue client-side display telemetry script using official WordPress script APIs
     */
    public static function enqueue_login_screen_detector() {
        wp_register_script('wcpscan-login-detector', false, [], (defined('WEBCAREPROSCAN_VERSION') ? WEBCAREPROSCAN_VERSION : '1.19.0'), true);
        wp_enqueue_script('wcpscan-login-detector');
        wp_add_inline_script('wcpscan-login-detector', '(function(){try{var s=document.getElementById("webcareproscan_screen_res");if(s&&window.screen){s.value=window.screen.width+"x"+window.screen.height+"@"+(window.devicePixelRatio||1);}var t=document.getElementById("webcareproscan_client_tz");if(t&&window.Intl){t.value=Intl.DateTimeFormat().resolvedOptions().timeZone||"";}}catch(e){}})();');
    }

    /**
     * Record login event into encrypted table
     */
    public static function on_user_login(string $user_login, \WP_User $user) {
        if (!$user->has_cap('edit_posts')) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;

        // Check if table exists
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if (!$table_exists) {
            \WebCareProScanner\Database\Migration::install();
        }

        $session_token = !empty(self::$last_auth_token) ? self::$last_auth_token : wp_get_session_token();
        if (empty($session_token)) {
            $manager = \WP_Session_Tokens::get_instance($user->ID);
            $all = $manager->get_all();
            if (!empty($all)) {
                $keys = array_keys($all);
                $session_token = end($keys);
            }
        }

        $token_hash    = $session_token ? substr(hash('sha256', $session_token), 0, 64) : '';
        $ip            = FirewallEngine::get_client_ip();
        $ua            = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : 'Unknown';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $screen_raw    = isset($_POST['webcareproscan_screen_res']) ? sanitize_text_field(wp_unslash($_POST['webcareproscan_screen_res'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $tz_raw        = isset($_POST['webcareproscan_client_tz']) ? sanitize_text_field(wp_unslash($_POST['webcareproscan_client_tz'])) : '';

        $parsed = self::parse_device_details($ua, $screen_raw);

        $auth_method = 'Username & Password';
        if (class_exists('\\WebCareProScanner\\Auth\\SessionSentinel') && !empty(\WebCareProScanner\Auth\SessionSentinel::$pending_auth_label)) {
            $auth_method = \WebCareProScanner\Auth\SessionSentinel::$pending_auth_label;
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Inspection during wp_login hook to determine if 2FA code was supplied
        } elseif (!empty($_POST['webcareproscan_2fa_code'])) {
            $auth_method = 'Password + 2FA TOTP Verified';
        } elseif (get_user_meta($user->ID, 'webcareproscan_is_temporary_support', true)) {
            $auth_method = 'Magic Support Link (Zero-Trust JIT)';
        } elseif (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) {
            $auth_method = 'XML-RPC Protocol';
        } elseif (defined('REST_REQUEST') && REST_REQUEST) {
            $auth_method = 'REST API Application Password';
        }

        $telemetry = [
            'ip'                => $ip,
            'user_agent'        => $ua,
            'browser'           => $parsed['browser'],
            'browser_version'   => $parsed['browser_version'],
            'platform'          => $parsed['platform'],
            'device_type'       => $parsed['device_type'],
            'screen_resolution' => $parsed['screen_resolution'],
            'viewport'          => $parsed['viewport'],
            'timezone'          => $tz_raw ?: 'UTC',
            'auth_method'       => $auth_method,
        ];

        // Encrypt everything with AES-256-GCM before writing to database
        $encrypted_data = SecretVault::encrypt((string) wp_json_encode($telemetry));

        $now = current_time('mysql');
        $now_gmt = gmdate('Y-m-d H:i:s');

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $wpdb->insert(
            $table,
            [
                'user_id'        => $user->ID,
                'session_token'  => $token_hash,
                'login_time'     => $now,
                'login_time_gmt' => $now_gmt,
                'last_seen'      => $now,
                'last_seen_gmt'  => $now_gmt,
                'encrypted_data' => $encrypted_data,
                'created_at'     => $now,
                'created_at_gmt' => $now_gmt,
            ],
            ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
        );

        // Keep last 25 logins per user to maintain high performance
        self::prune_old_logins($user->ID);
    }

    /**
     * Update active session heartbeat and telemetry (Screen size, Viewport)
     */
    public static function update_session_telemetry(int $user_id, array $client_telemetry) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;

        $session_token = wp_get_session_token();
        $token_hash    = $session_token ? substr(hash('sha256', $session_token), 0, 64) : '';

        if (empty($token_hash)) {
            // Find newest open session for this user
            $query = "SELECT * FROM `{$table}` WHERE user_id = %d AND logout_time IS NULL ORDER BY id DESC LIMIT 1";
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $row = $wpdb->get_row(
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $wpdb->prepare($query, $user_id)
            );
        } else {
            $query = "SELECT * FROM `{$table}` WHERE user_id = %d AND session_token = %s ORDER BY id DESC LIMIT 1";
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $row = $wpdb->get_row(
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $wpdb->prepare($query, $user_id, $token_hash)
            );
        }

        if (!$row) {
            return false;
        }

        $decrypted_raw = SecretVault::decrypt($row->encrypted_data);
        $payload = is_string($decrypted_raw) ? (json_decode($decrypted_raw, true) ?: []) : [];

        if (!empty($client_telemetry['screen_resolution'])) {
            $payload['screen_resolution'] = sanitize_text_field($client_telemetry['screen_resolution']);
        }
        if (!empty($client_telemetry['viewport'])) {
            $payload['viewport'] = sanitize_text_field($client_telemetry['viewport']);
        }
        if (!empty($client_telemetry['timezone'])) {
            $payload['timezone'] = sanitize_text_field($client_telemetry['timezone']);
        }

        $re_encrypted = SecretVault::encrypt((string) wp_json_encode($payload));
        $now = current_time('mysql');
        $now_gmt = gmdate('Y-m-d H:i:s');

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return $wpdb->update(
            $table,
            [
                'last_seen'      => $now,
                'last_seen_gmt'  => $now_gmt,
                'encrypted_data' => $re_encrypted,
            ],
            ['id' => $row->id],
            ['%s', '%s', '%s'],
            ['%d']
        );
    }

    /**
     * Record dynamic network IP change / shift during an active authenticated session.
     * When an administrator moves across Wi-Fi networks, cellular hot-spots, or VPNs,
     * this creates a discrete forensics record and adds the new IP to the IP Directory.
     *
     * @param int    $user_id
     * @param string $new_ip
     * @param string $session_token
     * @return bool
     */
    public static function record_session_ip_shift(int $user_id, string $new_ip, string $session_token): bool {
        if ($user_id <= 0 || empty($new_ip) || empty($session_token)) {
            return false;
        }

        // Failsafe: Ignore loopback or empty IPs
        if ($new_ip === '127.0.0.1' || $new_ip === '::1' || \WebCareProScanner\Firewall\FirewallEngine::is_cloudflare_ip($new_ip)) {
            return false;
        }

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;

        $token_hash = substr(hash('sha256', $session_token), 0, 64);

        // Fetch latest session history record for this user and token
        $query = "SELECT * FROM `{$table}` WHERE user_id = %d AND session_token = %s ORDER BY id DESC LIMIT 1";
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $row = $wpdb->get_row(
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $wpdb->prepare($query, $user_id, $token_hash)
        );

        // If the latest record already has this IP, throttle and do not duplicate
        if ($row) {
            $decrypted_raw = SecretVault::decrypt($row->encrypted_data);
            $data = is_string($decrypted_raw) ? (json_decode($decrypted_raw, true) ?: []) : [];
            if (!empty($data['ip']) && $data['ip'] === $new_ip) {
                return false;
            }
        }

        // Parse user agent and client telemetry
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';
        $parsed = self::parse_device_details($ua, '');

        $auth_method = 'Network Shift (Active Session)';

        $telemetry = [
            'ip'                => $new_ip,
            'user_agent'        => $ua,
            'browser'           => $parsed['browser'],
            'browser_version'   => $parsed['browser_version'],
            'platform'          => $parsed['platform'],
            'device_type'       => $parsed['device_type'],
            'screen_resolution' => $parsed['screen_resolution'],
            'viewport'          => $parsed['viewport'],
            'timezone'          => 'UTC',
            'auth_method'       => $auth_method,
        ];

        // Encrypt with AES-256-GCM before storage
        $encrypted_data = SecretVault::encrypt((string) wp_json_encode($telemetry));

        $now = current_time('mysql');
        $now_gmt = gmdate('Y-m-d H:i:s');

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $inserted = $wpdb->insert(
            $table,
            [
                'user_id'        => $user_id,
                'session_token'  => $token_hash,
                'login_time'     => $now,
                'login_time_gmt' => $now_gmt,
                'last_seen'      => $now,
                'last_seen_gmt'  => $now_gmt,
                'encrypted_data' => $encrypted_data,
                'created_at'     => $now,
                'created_at_gmt' => $now_gmt,
            ],
            ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
        );

        self::prune_old_logins($user_id);

        return (bool) $inserted;
    }

    /**
     * Mark session logged out
     */
    public static function on_user_logout() {
        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return;
        }

        $session_token = wp_get_session_token();
        $token_hash    = $session_token ? substr(hash('sha256', $session_token), 0, 64) : '';

        global $wpdb;
        $table   = $wpdb->prefix . self::TABLE_NAME;
        $now     = current_time('mysql');
        $now_gmt = gmdate('Y-m-d H:i:s');

        if ($token_hash) {
            $query = "UPDATE `{$table}` SET logout_time = %s, logout_time_gmt = %s WHERE user_id = %d AND session_token = %s AND logout_time IS NULL";
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->query(
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $wpdb->prepare($query, $now, $now_gmt, $user_id, $token_hash)
            );
        } else {
            $query = "UPDATE `{$table}` SET logout_time = %s, logout_time_gmt = %s WHERE user_id = %d AND logout_time IS NULL ORDER BY id DESC LIMIT 1";
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->query(
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $wpdb->prepare($query, $now, $now_gmt, $user_id)
            );
        }
    }

    /**
     * Mark session terminated via Session Sentinel
     */
    public static function record_session_terminated(int $user_id, string $session_token) {
        if ($user_id <= 0 || empty($session_token)) {
            return;
        }

        try {
            global $wpdb;
            if (!$wpdb) {
                return;
            }
            $table = $wpdb->prefix . self::TABLE_NAME;
            $now   = current_time('mysql');

            $raw_hash = substr(hash('sha256', $session_token), 0, 64);

            $query = "UPDATE `{$table}` SET logout_time = %s WHERE user_id = %d AND (session_token = %s OR session_token = %s) AND logout_time IS NULL";
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->query(
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $wpdb->prepare($query, $now, $user_id, $session_token, $raw_hash)
            );
        } catch (\Throwable $e) {
            // Silently suppress if table does not exist yet or DB query fails
        }
    }

    /**
     * Get decrypted login history for a specific user (Last 10 records by default)
     */
    public static function get_user_history(int $user_id, int $limit = 10): array {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;

        $user = get_userdata($user_id);
        if (!$user) {
            return [
                'success' => false,
                'message' => 'User not found'
            ];
        }

        // Ensure table exists
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if (!$table_exists) {
            \WebCareProScanner\Database\Migration::install();
        }

        // Calculate query limit: 0 or values >= 1000 retrieve full history
        $sql_limit = ($limit <= 0 || $limit >= 1000) ? 1000 : max(1, min(500, $limit));

        $query = "SELECT * FROM `{$table}` WHERE user_id = %d ORDER BY id DESC LIMIT %d";
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results(
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $wpdb->prepare($query, $user_id, $sql_limit)
        );

        // Get currently active sessions from WP core session tokens
        $manager = \WP_Session_Tokens::get_instance($user_id);
        $wp_sessions = $manager->get_all();
        $current_token = wp_get_session_token();

        // Retrieve current active sessions metadata to check for active tokens
        $sessions_meta = get_user_meta($user_id, 'webcareproscan_session_meta', true) ?: [];

        $history = [];
        $total_active_seconds = 0;
        $latest_login_time = null;

        // Build quick lookup of active session token hashes
        $active_token_hashes = [];
        if (!empty($wp_sessions) && is_array($wp_sessions)) {
            $now_ts = time();
            foreach ($wp_sessions as $verifier_key => $s_entry) {
                if (isset($s_entry['expiration']) && (int) $s_entry['expiration'] <= $now_ts) {
                    continue;
                }
                $active_token_hashes[$verifier_key] = true;
            }
        }

        foreach ($rows as $idx => $row) {
            $decrypted_raw = SecretVault::decrypt($row->encrypted_data);
            $data = is_string($decrypted_raw) ? (json_decode($decrypted_raw, true) ?: []) : [];

            $login_ts = strtotime($row->login_time);
            $logout_ts = !empty($row->logout_time) ? strtotime($row->logout_time) : null;
            $last_seen_ts = !empty($row->last_seen) ? strtotime($row->last_seen) : $login_ts;

            // Check if this record corresponds to an active WP session
            $is_active = false;
            if (empty($logout_ts) && !empty($wp_sessions)) {
                $row_token = (string) $row->session_token;
                if (!empty($row_token) && isset($active_token_hashes[$row_token])) {
                    $is_active = true;
                } elseif ($idx === 0) {
                    $is_active = true;
                }
            }

            // Duration calculation
            if ($is_active) {
                $duration_sec = max(1, time() - $login_ts);
                $duration_formatted = self::format_duration($duration_sec);
                if ($idx === 0) {
                    $total_active_seconds = $duration_sec;
                }
            } elseif ($logout_ts) {
                $duration_sec = max(1, $logout_ts - $login_ts);
                $duration_formatted = self::format_duration($duration_sec);
            } else {
                $duration_sec = max(1, $last_seen_ts - $login_ts);
                $duration_formatted = self::format_duration($duration_sec);
            }

            if ($idx === 0) {
                $latest_login_time = $row->login_time;
            }

            $row_ip = $data['ip'] ?? 'Unknown IP';

            $history[] = [
                'id'                 => (int) $row->id,
                'login_time'         => $row->login_time,
                'login_time_human'   => human_time_diff($login_ts, time()) . ' ago',
                'logout_time'        => $row->logout_time,
                'last_seen'          => $row->last_seen,
                'duration_seconds'   => $duration_sec,
                'duration_formatted' => $duration_formatted,
                'is_active'          => $is_active,
                'ip'                 => $row_ip,
                'browser'            => $data['browser'] ?? 'Browser',
                'browser_version'    => $data['browser_version'] ?? '',
                'platform'           => $data['platform'] ?? 'OS',
                'device_type'        => $data['device_type'] ?? 'Desktop',
                'screen_resolution'  => $data['screen_resolution'] ?? 'Standard Desktop',
                'viewport'           => $data['viewport'] ?? '',
                'timezone'           => $data['timezone'] ?? 'UTC',
                'user_agent'         => $data['user_agent'] ?? '',
                'auth_method'        => $data['auth_method'] ?? 'Password',
            ];
        }

        // If no rows were logged yet in custom table (e.g. initial install), generate fallback from active sessions
        if (empty($history) && !empty($wp_sessions)) {
            $client_ip = FirewallEngine::get_client_ip();
            $client_ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : 'Unknown';
            $parsed    = self::parse_device_details($client_ua, '');

            foreach ($wp_sessions as $token => $sdata) {
                $s_login = isset($sdata['login']) ? (int) $sdata['login'] : time();
                $dur = max(1, time() - $s_login);
                $session_ip = $sdata['ip'] ?? 'Unknown IP';

                $history[] = [
                    'id'                 => 1,
                    'login_time'         => date_i18n('Y-m-d H:i:s', $s_login),
                    'login_time_human'   => human_time_diff($s_login, time()) . ' ago',
                    'logout_time'        => null,
                    'last_seen'          => date_i18n('Y-m-d H:i:s', time()),
                    'duration_seconds'   => $dur,
                    'duration_formatted' => self::format_duration($dur),
                    'is_active'          => true,
                    'ip'                 => $session_ip,
                    'browser'            => $parsed['browser'],
                    'browser_version'    => $parsed['browser_version'],
                    'platform'           => $parsed['platform'],
                    'device_type'        => $parsed['device_type'],
                    'screen_resolution'  => '1920x1080 (Estimated)',
                    'viewport'           => '',
                    'timezone'           => 'UTC',
                    'user_agent'         => $sdata['ua'] ?? $client_ua,
                    'auth_method'        => 'Active WordPress Session',
                ];
                if ($total_active_seconds === 0) {
                    $total_active_seconds = $dur;
                    $latest_login_time = date_i18n('Y-m-d H:i:s', $s_login);
                }
            }
        }

        // If an active session is currently accessing from a dynamic shifted IP that hasn't yet been
        // committed to disk, ensure the active connection IP is represented in history so the IP Directory reflects it.
        if (!empty($wp_sessions) && !empty($history)) {
            $active_req_ip = FirewallEngine::get_client_ip();
            if (!empty($active_req_ip) && $active_req_ip !== '127.0.0.1' && $active_req_ip !== '::1' && !FirewallEngine::is_cloudflare_ip($active_req_ip)) {
                $known_ips = array_column($history, 'ip');
                if (!in_array($active_req_ip, $known_ips, true)) {
                    // Check if current user is the user whose history is being inspected
                    $current_uid = get_current_user_id();
                    if ($current_uid === $user_id) {
                        $cur_ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';
                        $parsed_cur = self::parse_device_details($cur_ua, '');
                        array_unshift($history, [
                            'id'                 => 0,
                            'login_time'         => current_time('mysql'),
                            'login_time_human'   => __('Active connection', 'webcare-pro-security'),
                            'logout_time'        => null,
                            'last_seen'          => current_time('mysql'),
                            'duration_seconds'   => 1,
                            'duration_formatted' => 'Active now',
                            'is_active'          => true,
                            'ip'                 => $active_req_ip,
                            'browser'            => $parsed_cur['browser'],
                            'browser_version'    => $parsed_cur['browser_version'],
                            'platform'           => $parsed_cur['platform'],
                            'device_type'        => $parsed_cur['device_type'],
                            'screen_resolution'  => $parsed_cur['screen_resolution'],
                            'viewport'           => $parsed_cur['viewport'],
                            'timezone'           => 'UTC',
                            'user_agent'         => $cur_ua,
                            'auth_method'        => 'Network Shift (Active Session)',
                        ]);
                    }
                }
            }
        }

        return [
            'success'                => true,
            'user'                   => [
                'id'           => $user->ID,
                'login'        => $user->user_login,
                'display_name' => $user->display_name ?: $user->user_login,
                'email'        => $user->user_email,
                'avatar_url'   => get_avatar_url($user->ID, ['size' => 96]),
                'roles'        => (array) $user->roles,
                'registered'   => $user->user_registered,
            ],
            'last_login_time'        => $latest_login_time ?: current_time('mysql'),
            'total_active_seconds'   => $total_active_seconds,
            'total_active_formatted' => self::format_duration($total_active_seconds),
            'active_sessions_count'  => count($wp_sessions),
            'history'                => $history,
        ];
    }

    /**
     * Format elapsed duration into human readable format: e.g. "1 hour 5 min 2s"
     */
    public static function format_duration(int $seconds): string {
        if ($seconds < 60) {
            return "{$seconds}s";
        }

        $days    = floor($seconds / 86400);
        $seconds = $seconds % 86400;
        $hours   = floor($seconds / 3600);
        $seconds = $seconds % 3600;
        $minutes = floor($seconds / 60);
        $secs    = $seconds % 60;

        $parts = [];
        if ($days > 0) {
            $parts[] = $days . ' ' . _n('day', 'days', $days, 'webcare-pro-security');
        }
        if ($hours > 0) {
            $parts[] = $hours . ' ' . _n('hour', 'hours', $hours, 'webcare-pro-security');
        }
        if ($minutes > 0) {
            $parts[] = $minutes . ' min';
        }
        if ($secs > 0 || empty($parts)) {
            $parts[] = $secs . 's';
        }

        return implode(' ', $parts);
    }

    /**
     * Parse User Agent into structured device details
     */
    public static function parse_device_details(string $ua, string $screen_raw = ''): array {
        $device_type = 'Desktop';
        $platform    = 'Windows';
        $browser     = 'Google Chrome';
        $version     = '';

        // Device Type
        if (preg_match('/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i', $ua)) {
            $device_type = 'Tablet';
        } elseif (preg_match('/(mobile|iphone|ipod|blackberry|opera mini|iemobile|wpdesktop)/i', $ua)) {
            $device_type = 'Mobile';
        }

        // Platform / OS
        if (stripos($ua, 'Windows NT 10.0') !== false) {
            $platform = 'Windows 10 / 11';
        } elseif (stripos($ua, 'Windows NT 6.3') !== false) {
            $platform = 'Windows 8.1';
        } elseif (stripos($ua, 'Windows NT 6.1') !== false) {
            $platform = 'Windows 7';
        } elseif (stripos($ua, 'Windows') !== false) {
            $platform = 'Windows';
        } elseif (stripos($ua, 'Macintosh') !== false || stripos($ua, 'Mac OS X') !== false) {
            $platform = 'macOS';
        } elseif (stripos($ua, 'Android') !== false) {
            $platform = 'Android';
        } elseif (stripos($ua, 'iPhone') !== false) {
            $platform = 'iOS (iPhone)';
        } elseif (stripos($ua, 'iPad') !== false) {
            $platform = 'iPadOS';
        } elseif (stripos($ua, 'Linux') !== false) {
            $platform = 'Linux';
        }

        // Browser & Version
        if (preg_match('/Edg\/([0-9.]+)/i', $ua, $m)) {
            $browser = 'Microsoft Edge';
            $version = $m[1];
        } elseif (preg_match('/Chrome\/([0-9.]+)/i', $ua, $m) && stripos($ua, 'Edg') === false) {
            $browser = 'Google Chrome';
            $version = $m[1];
        } elseif (preg_match('/Firefox\/([0-9.]+)/i', $ua, $m)) {
            $browser = 'Mozilla Firefox';
            $version = $m[1];
        } elseif (preg_match('/Version\/([0-9.]+).*Safari/i', $ua, $m)) {
            $browser = 'Apple Safari';
            $version = $m[1];
        } elseif (preg_match('/OPR\/([0-9.]+)/i', $ua, $m)) {
            $browser = 'Opera';
            $version = $m[1];
        }

        // Format screen resolution
        $screen_res = '1920x1080';
        $viewport   = '';
        if (!empty($screen_raw)) {
            $screen_res = $screen_raw;
        } elseif ($device_type === 'Mobile') {
            $screen_res = '390x844 (Mobile)';
        } elseif ($device_type === 'Tablet') {
            $screen_res = '820x1180 (Tablet)';
        }

        return [
            'device_type'       => $device_type,
            'platform'          => $platform,
            'browser'           => $browser,
            'browser_version'   => $version,
            'screen_resolution' => $screen_res,
            'viewport'          => $viewport,
        ];
    }

    /**
     * Prune older login records keeping recent 500 per user
     */
    private static function prune_old_logins(int $user_id) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;

        $query = "SELECT id FROM `{$table}` WHERE user_id = %d ORDER BY id DESC LIMIT 1 OFFSET 500";
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $cutoff_id = $wpdb->get_var(
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $wpdb->prepare($query, $user_id)
        );

        if ($cutoff_id) {
            $del_query = "DELETE FROM `{$table}` WHERE user_id = %d AND id < %d";
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->query(
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $wpdb->prepare($del_query, $user_id, $cutoff_id)
            );
        }
    }
}
