<?php
namespace WcpScanner\Firewall;

use WcpScanner\System\SettingsManager;
use WcpScanner\System\AuditLogger;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * MicroWafCompiler
 *
 * Compiles a zero-dependency, ultra-lean Preload Micro-WAF script that executes
 * in PHP's early request lifecycle via `auto_prepend_file` before WordPress core boots.
 *
 * Key Capabilities:
 * 1. Compiles active IP blocklists and high-confidence exploit signatures into OPcache-shared PHP arrays.
 * 2. Operates with near-zero memory footprint (<0.2MB RAM) and sub-microsecond latency.
 * 3. Appends security blocks in standard Linux format for Linux Fail2ban jails and CrowdSec parsers.
 * 4. Automatic server environment detection and safe `.user.ini` / `.htaccess` installer.
 * 5. Fail-safe kill switches and emergency bypass token support.
 *
 * Author: Mir Alamin (WebCare Pro)
 * Senior Linux SysAdmin & WordPress Security Engineer
 */
class MicroWafCompiler {

    const COMPILED_DIR_REL = 'wcp-security-scanner/waf-compiled';
    const COMPILED_FILE_NAME = 'micro-waf-compiled.php';
    const FAIL2BAN_LOG_REL = 'wcp-security-scanner/waf-logs/fail2ban.log';
    const OPTION_STATUS = 'wcpscan_micro_waf_status';
    const CAF_COMPILED_FILE_NAME = 'wcp-caf-compiled-rules.php';
    const OPTION_CAF_HMAC = 'wcp_caf_compiled_hmac';

    /**
     * Get the absolute path to the compiled Micro-WAF directory.
     *
     * @return string
     */
    public static function get_compiled_dir(): string {
        $upload_dir = wp_upload_dir();
        return trailingslashit($upload_dir['basedir']) . self::COMPILED_DIR_REL;
    }

    /**
     * Get the absolute path to the compiled Micro-WAF script.
     *
     * @return string
     */
    public static function get_compiled_file_path(): string {
        return trailingslashit(self::get_compiled_dir()) . self::COMPILED_FILE_NAME;
    }

    /**
     * Get the absolute path to the compiled CAF data rules.
     */
    public static function get_caf_compiled_file_path(): string {
        return trailingslashit(self::get_compiled_dir()) . self::CAF_COMPILED_FILE_NAME;
    }

    /**
     * Get the absolute path to the Fail2ban / CrowdSec log file.
     *
     * @return string
     */
    public static function get_fail2ban_log_path(): string {
        $upload_dir = wp_upload_dir();
        return trailingslashit($upload_dir['basedir']) . self::FAIL2BAN_LOG_REL;
    }

    /**
     * Check if the Preload Micro-WAF is actively running in the current PHP process.
     *
     * @return bool
     */
    public static function is_active_in_runtime(): bool {
        $auto_prepend = (string) ini_get('auto_prepend_file');
        if (empty($auto_prepend)) {
            return false;
        }

        $target = self::get_compiled_file_path();
        return (realpath($auto_prepend) === realpath($target) || str_contains($auto_prepend, self::COMPILED_FILE_NAME));
    }

    /**
     * Detect web server environment configuration target.
     *
     * @return array
     */
    public static function detect_server_target(): array {
        $sapi = strtolower(PHP_SAPI);
        $server_software = isset($_SERVER['SERVER_SOFTWARE']) ? strtolower(sanitize_text_field(wp_unslash($_SERVER['SERVER_SOFTWARE']))) : '';

        $target = 'user_ini';
        $filename = '.user.ini';
        $reason = 'PHP-FPM / FastCGI / CGI environment';

        if (str_contains($server_software, 'apache') || str_contains($server_software, 'litespeed')) {
            if ($sapi === 'apache2handler' || $sapi === 'litespeed') {
                $target = 'htaccess';
                $filename = '.htaccess';
                $reason = 'Apache or LiteSpeed with direct module execution';
            }
        }

        $root_path = ABSPATH;
        $target_file = trailingslashit($root_path) . $filename;
        $is_writable = wp_is_writable($root_path) || (file_exists($target_file) && wp_is_writable($target_file));

        return [
            'sapi'            => $sapi,
            'server_software' => $server_software,
            'target'          => $target,
            'filename'        => $filename,
            'target_file'     => $target_file,
            'is_writable'     => $is_writable,
            'reason'          => $reason,
        ];
    }

    /**
     * Compile active WAF rules, IP blocklists, and signatures into a zero-dependency PHP script.
     *
     * @param string|null $chained_file Optional pre-existing prepend script to chain after WCP execution.
     * @return array Result array with success bool and metadata.
     */
    /**
     * Alias for compile() to satisfy CAF lifecycle invocation.
     */
    public static function compile_script(?string $chained_file = null): bool {
        $result = self::compile($chained_file);
        return !empty($result['success']);
    }

    public static function compile(?string $chained_file = null): array {
        if ($chained_file === null) {
            $chained_file = (string) get_option('wcpscan_micro_waf_chained_file', '');
        }

        $dir = self::get_compiled_dir();
        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
            // Place silent index.php and hardened .htaccess
            file_put_contents(trailingslashit($dir) . 'index.php', "<?php\n// Silence is golden.\n");
            file_put_contents(trailingslashit($dir) . '.htaccess', "Order Deny,Allow\nDeny from all\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n");
        }

        $compiled_file = self::get_compiled_file_path();
        $fail2ban_log = self::get_fail2ban_log_path();

        // 1. Gather active IP blocklists
        $blocked_ips = [];
        $settings = SettingsManager::get_settings();
        $raw_blocked_text = !empty($settings['waf_blocked_ips']) ? (string) $settings['waf_blocked_ips'] : '';
        if (!empty($raw_blocked_text)) {
            $lines = explode("\n", $raw_blocked_text);
            foreach ($lines as $line) {
                $ip = trim($line);
                if (!empty($ip) && !str_starts_with($ip, '#')) {
                    $blocked_ips[] = $ip;
                }
            }
        }

        // Add curated botnet seed CIDRs from ThreatIntelService if enabled
        if (!empty($settings['waf_block_threat_intel_ips']) && class_exists('\\WcpScanner\\Firewall\\ThreatIntelService')) {
            $seed_ips = array_keys(\WcpScanner\Firewall\ThreatIntelService::get_seed_blacklisted_ips());
            $blocked_ips = array_unique(array_merge($blocked_ips, $seed_ips));
        }

        // 2. High-confidence zero-false-positive attack signatures for early drop
        $compiled_signatures = [
            'SQLI-CORE' => [
                'pattern' => '/(?:\b(?:union\s+(?:all\s+)?select|benchmark\s*\(|pg_sleep\s*\(|information_schema)\b)/i',
                'desc'    => 'High-Confidence SQL Injection Probe',
            ],
            'RCE-EXEC' => [
                'pattern' => '/(?:\b(?:passthru|shell_exec|exec|proc_open|popen)\s*\(|(?:eval|assert)\s*\(\s*(?:\$|_GET|_POST|_COOKIE|_REQUEST))/i',
                'desc'    => 'Remote Code Execution / Webshell Ingress',
            ],
            'LFI-PATH' => [
                'pattern' => '/(?:\.\.[\\\/]){2,}|(?:\/etc\/(?:passwd|shadow|hosts)|\bwindows[\\\/]win\.ini\b)/i',
                'desc'    => 'Path Traversal / Local File Inclusion Probe',
            ],
            'RECON-DOT' => [
                'pattern' => '/(?:\/\.env(?:\.local|\.prod|\.bak)?|\/\.git(?:\/|$)|\/wp-config\.php\.(?:bak|old|swp|save))/i',
                'desc'    => 'Sensitive File & Repository Reconnaissance',
            ],
        ];

        // 3. Generate emergency bypass token
        $bypass_token = get_option('wcpscan_micro_waf_bypass_token', '');
        if (empty($bypass_token)) {
            $bypass_token = wp_generate_password(32, false, false);
            update_option('wcpscan_micro_waf_bypass_token', $bypass_token);
        }

                // 4. Compile CAF (Context-Adaptive Firewall) Phase 1 Rules
        self::compile_caf_data_artifact();

        $code = self::generate_standalone_code($blocked_ips, $compiled_signatures, $fail2ban_log, $bypass_token, $chained_file);

        // Write compiled file atomically
        $temp_file = $compiled_file . '.tmp.' . wp_rand();
        $written = file_put_contents($temp_file, $code);
        if ($written === false) {
            return [
                'success' => false,
                'message' => __('Failed to write temporary Micro-WAF file to uploads directory.', 'wcp-security-scanner'),
            ];
        }

        // Rename atomically
        // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- Atomic move of compiled WAF cache.
        if (!rename($temp_file, $compiled_file)) {
            wp_delete_file($temp_file);
            return [
                'success' => false,
                'message' => __('Failed to atomically deploy compiled Micro-WAF script.', 'wcp-security-scanner'),
            ];
        }

        // Reset OPcache if available for the compiled file
        if (function_exists('opcache_invalidate')) {
            opcache_invalidate($compiled_file, true);
        }

        $status_data = [
            'compiled_at'       => time(),
            'compiled_at_gmt'   => gmdate('Y-m-d H:i:s'),
            'file_path'         => $compiled_file,
            'file_size'         => filesize($compiled_file),
            'blocked_ips_count' => count($blocked_ips),
            'signatures_count'  => count($compiled_signatures),
            'fail2ban_log'      => $fail2ban_log,
        ];
        update_option(self::OPTION_STATUS, $status_data);

        return [
            'success'     => true,
            'message'     => __('WCP Preload Micro-WAF successfully compiled.', 'wcp-security-scanner'),
            'status_data' => $status_data,
        ];
    }

    /**
     * Generate the complete standalone PHP source code for the Micro-WAF.
     */
    private static function generate_standalone_code(array $blocked_ips, array $signatures, string $fail2ban_log, string $bypass_token, string $chained_file = ''): string {
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_var_export -- Compiling static array representation for OPcache.
        $ips_export = var_export($blocked_ips, true);
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_var_export -- Compiling static array representation for OPcache.
        $sigs_export = var_export($signatures, true);
        $fail2ban_escaped = addslashes($fail2ban_log);
        $bypass_escaped = addslashes($bypass_token);

        $out = "<?php\n";
        $out .= "/**\n";
        $out .= " * WCP Preload Micro-WAF (Zero-Dependency Standalone Runtime)\n";
        $out .= " * Generated by WCP Security Scanner - Mir Alamin (WebCare Pro)\n";
        $out .= " * Executed via PHP auto_prepend_file before WordPress bootstrap.\n";
        $out .= " */\n\n";

        // Kill-switch 1: disabled constant in wp-config.php
        $out .= "if ((defined('WCP_DISABLE_MICRO_WAF') && WCP_DISABLE_MICRO_WAF) || (defined('WCP_CAF_DISABLE_PRELOAD') && WCP_CAF_DISABLE_PRELOAD)) {\n";
        $out .= "    return;\n";
        $out .= "}\n\n";

        // Kill-switch 2: filesystem sentinel killswitch
        $out .= "if (file_exists(dirname(__DIR__) . '/.killswitch') || file_exists(__DIR__ . '/.killswitch')) {\n";
        $out .= "    return;\n";
        $out .= "}\n\n";

        // Kill-switch 2: emergency query bypass token
        $out .= "if (isset(\$_GET['wcp_waf_bypass']) && hash_equals('{$bypass_escaped}', (string) \$_GET['wcp_waf_bypass'])) {\n";
        $out .= "    return;\n";
        $out .= "}\n\n";

        // Micro-WAF Core Engine with Self-Preservation Try/Catch
        $out .= "try {\n";
        $out .= "    (function() {\n";
        $out .= "        \$fail2ban_log = '{$fail2ban_escaped}';\n";
        $out .= "        \$blocked_ips = {$ips_export};\n";
        $out .= "        \$signatures  = {$sigs_export};\n\n";

        $out .= "        // 1. Resolve real client IP\n";
        $out .= "        \$ip = isset(\$_SERVER['REMOTE_ADDR']) ? trim(\$_SERVER['REMOTE_ADDR']) : '127.0.0.1';\n";
        $out .= "        \$cf_cidrs = ['173.245.48.0/20','103.21.244.0/22','103.22.200.0/22','103.31.4.0/22','141.101.64.0/18','108.162.192.0/18','190.93.240.0/20','188.114.96.0/20','197.234.240.0/22','198.41.128.0/17','162.158.0.0/15','104.16.0.0/13','104.24.0.0/14','172.64.0.0/13','131.0.72.0/22'];\n";
        $out .= "        \$is_cf_ip = false;\n";
        $out .= "        if (filter_var(\$ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {\n";
        $out .= "            \$r_long = ip2long(\$ip);\n";
        $out .= "            foreach (\$cf_cidrs as \$c_cidr) {\n";
        $out .= "                list(\$net, \$m) = explode('/', \$c_cidr);\n";
        $out .= "                \$mask_l = ~((1 << (32 - (int) \$m)) - 1);\n";
        $out .= "                if ((\$r_long & \$mask_l) === (ip2long(\$net) & \$mask_l)) { \$is_cf_ip = true; break; }\n";
        $out .= "            }\n";
        $out .= "        } elseif (filter_var(\$ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {\n";
        $out .= "            if (str_starts_with(\$ip, '2400:cb00:') || str_starts_with(\$ip, '2606:4700:') || str_starts_with(\$ip, '2803:f800:') || str_starts_with(\$ip, '2405:b500:') || str_starts_with(\$ip, '2405:8100:') || str_starts_with(\$ip, '2a06:98c0:')) { \$is_cf_ip = true; }\n";
        $out .= "        }\n";
        $out .= "        if (\$is_cf_ip && isset(\$_SERVER['HTTP_CF_CONNECTING_IP']) && filter_var(\$_SERVER['HTTP_CF_CONNECTING_IP'], FILTER_VALIDATE_IP)) {\n";
        $out .= "            \$ip = trim(\$_SERVER['HTTP_CF_CONNECTING_IP']);\n";
        $out .= "        }\n\n";

        $out .= "        // 2. Fast IP & CIDR match\n";
        $out .= "        \$ip_blocked = false;\n";
        $out .= "        foreach (\$blocked_ips as \$rule_ip) {\n";
        $out .= "            if (\$ip === \$rule_ip) { \$ip_blocked = true; break; }\n";
        $out .= "            if (str_contains(\$rule_ip, '/')) {\n";
        $out .= "                list(\$subnet, \$mask) = explode('/', \$rule_ip, 2);\n";
        $out .= "                if (filter_var(\$ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && filter_var(\$subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {\n";
        $out .= "                    \$ip_long = ip2long(\$ip);\n";
        $out .= "                    \$sub_long = ip2long(\$subnet);\n";
        $out .= "                    \$mask_long = ~((1 << (32 - (int) \$mask)) - 1);\n";
        $out .= "                    if ((\$ip_long & \$mask_long) === (\$sub_long & \$mask_long)) {\n";
        $out .= "                        \$ip_blocked = true;\n";
        $out .= "                        break;\n";
        $out .= "                    }\n";
        $out .= "                }\n";
        $out .= "            }\n";
        $out .= "        }\n\n";

        $out .= "        if (\$ip_blocked) {\n";
        $out .= "            wcp_micro_waf_block(\$ip, 'IP-BLOCKLIST', 'Connecting IP is present in WCP Blacklist / Threat Intel', \$fail2ban_log);\n";
        $out .= "        }\n\n";

        $out .= "        // 3. Inspect URI and Query String for high-confidence attack vectors\n";
        $out .= "        \$uri = isset(\$_SERVER['REQUEST_URI']) ? (string) \$_SERVER['REQUEST_URI'] : '';\n";
        $out .= "        \$query = isset(\$_SERVER['QUERY_STRING']) ? (string) \$_SERVER['QUERY_STRING'] : '';\n";
        $out .= "        \$target_text = urldecode(\$uri . ' ' . \$query);\n\n";

        // 4. Context-Adaptive Firewall (CAF) Preload Enforcement
        $caf_compiled_path = self::get_caf_compiled_file_path();
        $caf_compiled_escaped = addslashes($caf_compiled_path);
        $caf_sig_escaped = addslashes($caf_compiled_path . '.sig');
        $salt = function_exists('wp_salt') ? wp_salt('auth') : 'wcp-caf-fallback-salt';
        $salt_escaped = addslashes($salt);

        $out .= "        // 4. Context-Adaptive Firewall (CAF): Inactive component lockdown & verified artifact validation\n";
        $out .= "        \$caf_data_file = '{$caf_compiled_escaped}';\n";
        $out .= "        \$caf_sig_file  = '{$caf_sig_escaped}';\n";
        $out .= "        if (file_exists(\$caf_data_file) && file_exists(\$caf_sig_file)) {\n";
        $out .= "            \$sig_content = trim((string) @file_get_contents(\$caf_sig_file));\n";
        $out .= "            \$raw_php = (string) @file_get_contents(\$caf_data_file);\n";
        $out .= "            \$expected_hmac = hash_hmac('sha256', \$raw_php, '{$salt_escaped}');\n";
        $out .= "            // Fail-open security guardrail: only execute artifact if cryptographic signature is intact\n";
        $out .= "            if (!empty(\$sig_content) && hash_equals(\$expected_hmac, \$sig_content)) {\n";
        $out .= "                \$caf_rules = include \$caf_data_file;\n";
        $out .= "                if (is_array(\$caf_rules) && !empty(\$caf_rules['lock_dormant_surface'])) {\n";
        $out .= "                    // 1. Inactive plugins directory probe drop\n";
        $out .= "                    \$dormant_plugins = !empty(\$caf_rules['inactive_plugin_slugs']) && is_array(\$caf_rules['inactive_plugin_slugs']) ? \$caf_rules['inactive_plugin_slugs'] : [];\n";
        $out .= "                    if (!empty(\$dormant_plugins)) {\n";
        $out .= "                        foreach (\$dormant_plugins as \$d_slug) {\n";
        $out .= "                            if (strpos(\$target_text, '/wp-content/plugins/' . \$d_slug . '/') !== false) {\n";
        $out .= "                                wcp_micro_waf_block(\$ip, 'WAF-CAF-DORMANT-SURFACE', 'Request targets inactive component directory (' . \$d_slug . ') under CAF lockdown policy', \$fail2ban_log);\n";
        $out .= "                            }\n";
        $out .= "                        }\n";
        $out .= "                    }\n\n";

        $out .= "                    // 2. Unregistered / Uninstalled REST API namespace probe drop\n";
        $out .= "                    if (strpos(\$uri, '/wp-json/') !== false) {\n";
        $out .= "                        \$active_namespaces = !empty(\$caf_rules['active_rest_namespaces']) && is_array(\$caf_rules['active_rest_namespaces']) ? \$caf_rules['active_rest_namespaces'] : [];\n";
        $out .= "                        \$rest_path = substr(\$uri, strpos(\$uri, '/wp-json/') + 9);\n";
        $out .= "                        \$rest_path_clean = strtok(\$rest_path, '?');\n";
        $out .= "                        \$rest_route = trim((string) \$rest_path_clean, '/');\n";
        $out .= "                        if (\$rest_route !== '' && !empty(\$active_namespaces)) {\n";
        $out .= "                            \$namespace_matched = false;\n";
        $out .= "                            foreach (\$active_namespaces as \$ns) {\n";
        $out .= "                                \$ns_clean = trim((string) \$ns, '/');\n";
        $out .= "                                if (\$ns_clean !== '' && (\$rest_route === \$ns_clean || strpos(\$rest_route, \$ns_clean . '/') === 0 || strpos(\$ns_clean, \$rest_route . '/') === 0)) {\n";
        $out .= "                                    \$namespace_matched = true;\n";
        $out .= "                                    break;\n";
        $out .= "                                }\n";
        $out .= "                            }\n";
        $out .= "                            if (!\$namespace_matched && !str_starts_with(\$rest_route, 'wp/') && \$rest_route !== 'wp') {\n";
        $out .= "                                \$single_candidate = explode('/', \$rest_route)[0] ?? \$rest_route;\n";
        $out .= "                                wcp_micro_waf_block(\$ip, 'WAF-CAF-DORMANT-REST-NAMESPACE', 'Request probes dormant or uninstalled REST namespace (' . htmlspecialchars(\$single_candidate, ENT_QUOTES, 'UTF-8') . ')', \$fail2ban_log);\n";
        $out .= "                            }\n";
        $out .= "                        }\n";
        $out .= "                    }\n\n";

        $out .= "                    // 3. Unauthenticated admin-ajax.php probe lockdown against dormant plugin actions\n";
        $out .= "                    if (strpos(\$uri, 'admin-ajax.php') !== false) {\n";
        $out .= "                        \$has_auth_cookie = false;\n";
        $out .= "                        if (!empty(\$_COOKIE)) {\n";
        $out .= "                            foreach (array_keys(\$_COOKIE) as \$c_name) {\n";
        $out .= "                                if (strpos((string) \$c_name, 'wordpress_logged_in_') === 0) {\n";
        $out .= "                                    \$has_auth_cookie = true;\n";
        $out .= "                                    break;\n";
        $out .= "                                }\n";
        $out .= "                            }\n";
        $out .= "                        }\n";
        $out .= "                        if (!\$has_auth_cookie) {\n";
        $out .= "                            \$ajax_action = '';\n";
        $out .= "                            if (isset(\$_GET['action'])) {\n";
        $out .= "                                \$ajax_action = trim((string) \$_GET['action']);\n";
        $out .= "                            } elseif (isset(\$_POST['action'])) {\n";
        $out .= "                                \$ajax_action = trim((string) \$_POST['action']);\n";
        $out .= "                            }\n";
        $out .= "                            if (!empty(\$ajax_action)) {\n";
        $out .= "                                \$allowed_nopriv = !empty(\$caf_rules['allowed_nopriv_actions']) && is_array(\$caf_rules['allowed_nopriv_actions']) ? \$caf_rules['allowed_nopriv_actions'] : [];\n";
        $out .= "                                if (!in_array(\$ajax_action, \$allowed_nopriv, true)) {\n";
        $out .= "                                    // Specifically verify if action belongs to a known dormant/deactivated plugin\n";
        $out .= "                                    \$is_dormant_action = false;\n";
        $out .= "                                    if (!empty(\$dormant_plugins)) {\n";
        $out .= "                                        foreach (\$dormant_plugins as \$d_slug) {\n";
        $out .= "                                            \$d_prefix = str_replace('-', '_', \$d_slug);\n";
        $out .= "                                            if (str_starts_with(\$ajax_action, \$d_prefix . '_') || str_starts_with(\$ajax_action, \$d_slug . '_')) {\n";
        $out .= "                                                \$is_dormant_action = true;\n";
        $out .= "                                                break;\n";
        $out .= "                                            }\n";
        $out .= "                                        }\n";
        $out .= "                                    }\n";
        $out .= "                                    if (\$is_dormant_action) {\n";
        $out .= "                                        wcp_micro_waf_block(\$ip, 'WAF-CAF-DORMANT-AJAX-ACTION', 'Unauthenticated probe on dormant plugin AJAX action (' . htmlspecialchars(substr(\$ajax_action, 0, 40), ENT_QUOTES, 'UTF-8') . ')', \$fail2ban_log);\n";
        $out .= "                                    }\n";
        $out .= "                                }\n";
        $out .= "                            }\n";
        $out .= "                        }\n";
        $out .= "                    }\n";
        $out .= "                }\n";
        $out .= "            }\n";
        $out .= "        }\n\n";

        $out .= "        foreach (\$signatures as \$rule_id => \$sig) {\n";
        $out .= "            if (preg_match(\$sig['pattern'], \$target_text)) {\n";
        $out .= "                wcp_micro_waf_block(\$ip, \$rule_id, \$sig['desc'], \$fail2ban_log);\n";
        $out .= "            }\n";
        $out .= "        }\n";
        $out .= "    })();\n";
        $out .= "} catch (\\Throwable \$e) {\n";
        $out .= "    // Self-preservation: Log silently to PHP error_log so host WordPress bootstrap is NEVER killed\n";
        $out .= "    @error_log('[WCP Micro-WAF Preload Error] Intercepted: ' . \$e->getMessage());\n";
        $out .= "}\n\n";

        // Chained pre-existing auto_prepend_file script (e.g. Wordfence or hosting runtime)
        if (!empty($chained_file)) {
            $chained_escaped = addslashes($chained_file);
            $out .= "// Chained pre-existing auto_prepend_file runtime\n";
            $out .= "if (file_exists('{$chained_escaped}')) {\n";
            $out .= "    require_once '{$chained_escaped}';\n";
            $out .= "}\n\n";
        }

        // Responder function
        $out .= "function wcp_micro_waf_block(string \$ip, string \$rule_id, string \$desc, string \$fail2ban_log): void {\n";
        $out .= "    // Log in Linux Fail2ban / CrowdSec compatible format (strip CRLF to prevent log injection)\n";
        $out .= "    \$timestamp = gmdate('Y-m-d H:i:s');\n";
        $out .= "    \$uri = isset(\$_SERVER['REQUEST_URI']) ? str_replace([\"\\r\", \"\\n\"], '', substr(\$_SERVER['REQUEST_URI'], 0, 200)) : '/';\n";
        $out .= "    \$method = isset(\$_SERVER['REQUEST_METHOD']) ? str_replace([\"\\r\", \"\\n\"], '', substr(\$_SERVER['REQUEST_METHOD'], 0, 10)) : 'GET';\n";
        $out .= "    \$log_entry = sprintf(\"[%s] [WCP-MICRO-WAF] [BLOCKED] IP: %s | Rule: %s | URI: %s | Method: %s\\n\", \$timestamp, \$ip, \$rule_id, \$uri, \$method);\n";
        $out .= "    @file_put_contents(\$fail2ban_log, \$log_entry, FILE_APPEND | LOCK_EX);\n\n";

        $out .= "    // Respond with HTTP 403 Forbidden\n";
        $out .= "    if (!headers_sent()) {\n";
        $out .= "        http_response_code(403);\n";
        $out .= "        header('HTTP/1.1 403 Forbidden');\n";
        $out .= "        header('Content-Type: text/html; charset=UTF-8');\n";
        $out .= "        header('X-WCP-Defense: Preload-Micro-WAF-Active');\n";
        $out .= "        header('Connection: close');\n";
        $out .= "    }\n\n";

        $out .= "    echo '<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"UTF-8\"><title>403 Forbidden - WCP Micro-WAF</title>';\n";
        $out .= "    echo '<style>body{font-family:-apple-system,BlinkMacSystemFont,\"Segoe UI\",Roboto,sans-serif;background:#090d16;color:#f8fafc;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;padding:20px;box-sizing:border-box;}';\n";
        $out .= "    echo '.card{background:#0f172a;border:1px solid #1e293b;border-radius:12px;padding:32px;max-width:540px;width:100%;box-shadow:0 10px 25px rgba(0,0,0,0.5);}';\n";
        $out .= "    echo 'h1{font-size:22px;color:#f43f5e;margin-top:0;display:flex;align-items:center;gap:10px;}';\n";
        $out .= "    echo 'p{color:#94a3b8;font-size:14px;line-height:1.6;}';\n";
        $out .= "    echo '.meta{background:#1e293b;padding:12px 16px;border-radius:8px;font-family:monospace;font-size:12px;color:#38bdf8;margin:18px 0;word-break:break-all;}';\n";
        $out .= "    echo '.footer{color:#64748b;font-size:11px;margin-top:24px;border-top:1px solid #1e293b;padding-top:12px;}';\n";
        $out .= "    echo '</style></head><body><div class=\"card\">';\n";
        $out .= "    echo '<h1>Access Denied (403)</h1>';\n";
        $out .= "    echo '<p>Your request was intercepted by the WCP Zero-Latency Preload Micro-WAF due to a verified security policy violation.</p>';\n";
        $out .= "    echo '<div class=\"meta\"><strong>Client IP:</strong> ' . htmlspecialchars(\$ip, ENT_QUOTES, 'UTF-8') . '<br><strong>Trigger:</strong> ' . htmlspecialchars(\$rule_id, ENT_QUOTES, 'UTF-8') . '<br><strong>Timestamp:</strong> ' . htmlspecialchars(\$timestamp, ENT_QUOTES, 'UTF-8') . ' UTC</div>';\n";
        $out .= "    echo '<p>If you believe this is an error, please contact the site administrator.</p>';\n";
        $out .= "    echo '<div class=\"footer\">Protected by WCP Security Scanner &bull; Zero-Resource Preload Shield</div>';\n";
        $out .= "    echo '</div></body></html>';\n";
        $out .= "    exit;\n";
        $out .= "}\n";

        return $out;
    }

    /**
     * Install the Preload Micro-WAF directive into .user.ini or .htaccess.
     *
     * @return array
     */
    public static function install_preload(): array {
        $target_info = self::detect_server_target();
        $target_file = $target_info['target_file'];
        $compiled_file = self::get_compiled_file_path();

        $begin_marker = '### BEGIN WCP_MICRO_WAF';
        $end_marker   = '### END WCP_MICRO_WAF';

        $existing_content = file_exists($target_file) ? (string) file_get_contents($target_file) : '';

        // Strip previous WCP block if present
        $clean_content = preg_replace('/' . preg_quote($begin_marker, '/') . '[\s\S]*?' . preg_quote($end_marker, '/') . '\s*/i', '', $existing_content);

        // Detect if another security plugin or hosting environment already configured auto_prepend_file
        $chained_file = '';
        if (preg_match('/(?:auto_prepend_file\s*=\s*[\'"]?([^\r\n\'"]+)[\'"]?|php_value\s+auto_prepend_file\s+[\'"]?([^\r\n\'"]+)[\'"]?)/i', $clean_content, $m)) {
            $detected = trim(!empty($m[1]) ? $m[1] : ($m[2] ?? ''));
            if (!empty($detected) && !str_contains($detected, self::COMPILED_FILE_NAME) && file_exists($detected)) {
                $chained_file = $detected;
                update_option('wcpscan_micro_waf_chained_file', $chained_file);
            }
        }

        // Compile first with chained script if detected
        $compile_res = self::compile($chained_file);
        if (!$compile_res['success']) {
            return $compile_res;
        }

        // Build directive block
        $block = "\n" . $begin_marker . "\n";
        if ($target_info['target'] === 'user_ini') {
            $block .= "; WCP Security Scanner Zero-Latency Preload Micro-WAF\n";
            $block .= "auto_prepend_file = '{$compiled_file}'\n";
        } else {
            $block .= "# WCP Security Scanner Zero-Latency Preload Micro-WAF\n";
            $block .= "<IfModule mod_php.c>\n";
            $block .= "    php_value auto_prepend_file '{$compiled_file}'\n";
            $block .= "</IfModule>\n";
            $block .= "<IfModule mod_php7.c>\n";
            $block .= "    php_value auto_prepend_file '{$compiled_file}'\n";
            $block .= "</IfModule>\n";
            $block .= "<IfModule mod_php8.c>\n";
            $block .= "    php_value auto_prepend_file '{$compiled_file}'\n";
            $block .= "</IfModule>\n";
        }
        $block .= $end_marker . "\n";

        $final_content = trim($clean_content) . "\n" . $block;

        $written = file_put_contents($target_file, $final_content);
        if ($written === false) {
            return [
                'success' => false,
                'message' => sprintf(
                    /* translators: %s: file path */
                    __('Unable to write preload directive into %s. Please verify file permissions.', 'wcp-security-scanner'),
                    $target_file
                ),
            ];
        }

        AuditLogger::log('micro_waf_installed', [
            'target_file'   => $target_file,
            'compiled_file' => $compiled_file,
            'chained_file'  => $chained_file,
            'environment'   => $target_info['reason'],
        ]);

        return [
            'success'     => true,
            'message'     => sprintf(
                /* translators: 1: filename, 2: environment description */
                __('Preload Micro-WAF installed successfully into %1$s (%2$s).', 'wcp-security-scanner'),
                $target_info['filename'],
                $target_info['reason']
            ),
            'target_file' => $target_file,
            'is_active'   => self::is_active_in_runtime(),
        ];
    }

    /**
     * Uninstall the Preload Micro-WAF directive from .user.ini and .htaccess.
     *
     * @return array
     */
    public static function uninstall_preload(): array {
        $root_path = ABSPATH;
        $files = [
            trailingslashit($root_path) . '.user.ini',
            trailingslashit($root_path) . '.htaccess',
        ];

        $begin_marker = '### BEGIN WCP_MICRO_WAF';
        $end_marker   = '### END WCP_MICRO_WAF';
        $modified_count = 0;
        $chained_file = (string) get_option('wcpscan_micro_waf_chained_file', '');
        delete_option('wcpscan_micro_waf_chained_file');

        foreach ($files as $file) {
            if (file_exists($file) && wp_is_writable($file)) {
                $content = (string) file_get_contents($file);
                if (str_contains($content, $begin_marker)) {
                    $cleaned = preg_replace('/' . preg_quote($begin_marker, '/') . '[\s\S]*?' . preg_quote($end_marker, '/') . '\s*/i', '', $content);
                    // If an external chained prepend previously existed, restore its single directive
                    if (!empty($chained_file) && !str_contains($cleaned, 'auto_prepend_file')) {
                        if (str_ends_with($file, '.user.ini')) {
                            $cleaned = trim($cleaned) . "\nauto_prepend_file = '{$chained_file}'\n";
                        } else {
                            $cleaned = trim($cleaned) . "\n<IfModule mod_php.c>\n    php_value auto_prepend_file '{$chained_file}'\n</IfModule>\n";
                        }
                    }
                    file_put_contents($file, trim($cleaned) . "\n");
                    $modified_count++;
                }
            }
        }

        AuditLogger::log('micro_waf_uninstalled', [
            'modified_count' => $modified_count,
        ]);

        return [
            'success' => true,
            'message' => __('WCP Preload Micro-WAF uninstalled successfully.', 'wcp-security-scanner'),
        ];
    }

    /**
     * Get overall Micro-WAF status telemetry.
     *
     * @return array
     */
    public static function get_status(): array {
        $compiled_file = self::get_compiled_file_path();
        $is_compiled = file_exists($compiled_file);
        $is_active = self::is_active_in_runtime();
        $target_info = self::detect_server_target();

        $saved_status = get_option(self::OPTION_STATUS, []);
        $bypass_token = get_option('wcpscan_micro_waf_bypass_token', '');
        $fail2ban_log = self::get_fail2ban_log_path();

        $recent_drops = [];
        if (file_exists($fail2ban_log)) {
            $lines = file($fail2ban_log, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if (is_array($lines)) {
                $recent_drops = array_slice(array_reverse($lines), 0, 15);
            }
        }

        return [
            'is_compiled'       => $is_compiled,
            'is_active'         => $is_active,
            'auto_prepend_ini'  => (string) ini_get('auto_prepend_file'),
            'compiled_file'     => $compiled_file,
            'file_size_bytes'   => $is_compiled ? filesize($compiled_file) : 0,
            'target_info'       => $target_info,
            'saved_status'      => $saved_status,
            'bypass_token'      => $bypass_token,
            'fail2ban_log'      => $fail2ban_log,
            'recent_drops'      => $recent_drops,
            'recent_drop_count' => count($recent_drops),
        ];
    }

    /**
     * Compile active CAF data rules into a signed static array artifact.
     */
    public static function compile_caf_data_artifact(): bool {
        $caf_file = self::get_caf_compiled_file_path();
        $sig_file = $caf_file . '.sig';

        $snapshot = null;
        $active_profile = 'balanced';
        $lock_dormant = true;
        $conflict_exemptions = [];
        $scoped_patches = [];

        if (class_exists('\\WcpScanner\\Firewall\\CAF\\AdaptiveFirewallAdvisor')) {
            $advisor = new \WcpScanner\Firewall\CAF\AdaptiveFirewallAdvisor();
            $snapshot = $advisor->get_stack_snapshot();
            $matrix   = $advisor->get_recommendations_matrix($snapshot);

            $active_profile      = (string) ($matrix['current_profile'] ?? 'balanced');
            $lock_dormant        = !empty($matrix['lock_dormant_surface']);
            $conflict_exemptions = (array) ($matrix['conflict_exemptions'] ?? []);
            $scoped_patches      = array_column((array) ($matrix['must_enable_patches'] ?? []), 'id');
        }

        $inactive_plugin_slugs = $snapshot ? array_keys($snapshot->inactive_plugins) : [];
        $inactive_theme_slugs  = $snapshot ? array_keys($snapshot->inactive_themes) : [];
        $active_rest_namespaces= $snapshot && !empty($snapshot->rest_namespaces) ? array_values(array_unique($snapshot->rest_namespaces)) : ['wp/v2', 'oembed/1.0'];
        $snapshot_hash         = $snapshot ? $snapshot->snapshot_hash : '';

        // Extract registered nopriv AJAX actions from $wp_filter if available
        global $wp_filter;
        $allowed_nopriv_actions = [];
        if (!empty($wp_filter) && is_array($wp_filter)) {
            foreach (array_keys($wp_filter) as $hook_name) {
                if (is_string($hook_name) && str_starts_with($hook_name, 'wp_ajax_nopriv_')) {
                    $allowed_nopriv_actions[] = substr($hook_name, 15);
                }
            }
        }

        // Merge standard WooCommerce & Core guest AJAX safe-passes
        $default_guest_ajax = [
            'woocommerce_get_refreshed_fragments',
            'woocommerce_apply_coupon',
            'woocommerce_remove_coupon',
            'woocommerce_update_shipping_method',
            'woocommerce_get_cart_totals',
            'woocommerce_update_order_review',
            'woocommerce_add_to_cart',
            'woocommerce_remove_from_cart',
            'woocommerce_checkout',
            'woocommerce_get_variation',
            'woocommerce_get_customer_location',
            'wcp_flush_cf_ban_queue',
            'heartbeat',
        ];
        $allowed_nopriv_actions = array_values(array_unique(array_merge($allowed_nopriv_actions, $default_guest_ajax)));

        $artifact_data = [
            'version'                => defined('WCPSCAN_VERSION') ? WCPSCAN_VERSION : '2.4.0',
            'generated_at'           => time(),
            'snapshot_hash'          => $snapshot_hash,
            'active_profile'         => $active_profile,
            'lock_dormant_surface'   => $lock_dormant,
            'inactive_plugin_slugs'  => $inactive_plugin_slugs,
            'inactive_theme_slugs'   => $inactive_theme_slugs,
            'active_rest_namespaces' => $active_rest_namespaces,
            'allowed_nopriv_actions' => $allowed_nopriv_actions,
            'conflict_exemptions'    => $conflict_exemptions,
            'scoped_virtual_patches' => $scoped_patches,
        ];

        $php_code = "<?php\n// Auto-generated by WCP MicroWafCompiler - DO NOT EDIT MANUALLY.\nreturn "
                  // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_var_export -- Compiling static data array artifact for OPcache bytecode caching.
                  . var_export($artifact_data, true) . ";\n";

        // Security Guardrail: Verify generated string contains strictly array/literal tokens (zero function calls)
        if (!self::assert_strictly_data_tokens($php_code)) {
            return false;
        }

        $temp_file = $caf_file . '.tmp.' . wp_rand();
        if (file_put_contents($temp_file, $php_code) === false) {
            return false;
        }

        // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- Atomic move of compiled WAF cache.
        if (!rename($temp_file, $caf_file)) {
            wp_delete_file($temp_file);
            return false;
        }

        // Detached HMAC-SHA256 signature
        $salt = function_exists('wp_salt') ? wp_salt('auth') : 'wcp-caf-fallback-salt';
        $hmac = hash_hmac('sha256', $php_code, $salt);
        update_option(self::OPTION_CAF_HMAC, $hmac);
        file_put_contents($sig_file, $hmac);

        if (function_exists('opcache_invalidate')) {
            opcache_invalidate($caf_file, true);
        }

        return true;
    }

    /**
     * AST Token Validator: Verifies that code contains strictly data array tokens and zero function calls.
     */
    public static function assert_strictly_data_tokens(string $code): bool {
        $allowed_tokens = [
            T_OPEN_TAG,
            T_RETURN,
            T_ARRAY,
            T_CONSTANT_ENCAPSED_STRING,
            T_LNUMBER,
            T_DNUMBER,
            T_DOUBLE_ARROW,
            T_WHITESPACE,
            T_COMMENT,
            T_DOC_COMMENT,
            T_STRING,
        ];

        $tokens = token_get_all($code);
        foreach ($tokens as $token) {
            if (is_array($token)) {
                if (!in_array($token[0], $allowed_tokens, true)) {
                    return false;
                }
                // Disallow arbitrary functions or constants (only allow true, false, null)
                if ($token[0] === T_STRING && !in_array(strtolower($token[1]), ['true', 'false', 'null', 'array'], true)) {
                    return false;
                }
            } else {
                // Single character tokens allowed: ()[],;
                if (!in_array($token, ['(', ')', '[', ']', ',', ';'], true)) {
                    return false;
                }
            }
        }

        return true;
    }

}
