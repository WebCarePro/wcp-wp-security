<?php
namespace WcpScanner\Database;

use WcpScanner\Findings\Finding;
use WcpScanner\Resource\ResourceMonitor;

if (!defined('ABSPATH')) {
    exit;
}

class DatabaseScanner {

    private $table_scanner;
    private $option_scanner;
    private $rogue_admin_detector;

    public function __construct() {
        $this->table_scanner = new TableScanner();
        $this->option_scanner = new OptionScanner();
        $this->rogue_admin_detector = new RogueAdminAnomalyDetector();
    }

    /**
     * Run full database inspection with resource awareness.
     *
     * @param string $scan_id
     * @param int $batch_size Rows per table batch
     * @return Finding[]
     */
    public function scan($scan_id, $batch_size = 100) {
        $findings = [];
        $monitor = new ResourceMonitor(70, 20, 'balanced');
        $adaptive_row_batch = $monitor->get_adaptive_batch_size($batch_size);

        // 1. Audit wp_options first
        $option_findings = $this->option_scanner->scan_options($scan_id);
        $findings = array_merge($findings, $option_findings);

        // 2. Audit Rogue Administrators & Database Micro-Anomalies
        $rogue_findings = $this->rogue_admin_detector->scan((string) $scan_id);
        $findings = array_merge($findings, $rogue_findings);

        // 3. Discover all tables
        $tables = $this->table_scanner->get_tables();

        foreach ($tables as $table) {
            if ($monitor->is_nearing_limits()) {
                break; // Stop early to prevent server strain
            }

            $meta = $this->table_scanner->get_table_metadata($table);
            if (empty($meta['columns'])) {
                continue;
            }

            $cursor = 0;
            while ($cursor !== null) {
                if ($monitor->throttle_and_check()) {
                    break 2;
                }

                $batch_res = $this->table_scanner->scan_table_batch(
                    $table,
                    $meta['columns'],
                    $meta['primary_key'],
                    $cursor,
                    $adaptive_row_batch,
                    $scan_id
                );

                if (!empty($batch_res['findings'])) {
                    $findings = array_merge($findings, $batch_res['findings']);
                }

                $cursor = $batch_res['next_cursor'];
            }
        }

        return $findings;
    }

    public function get_table_scanner() {
        return $this->table_scanner;
    }

    public function get_option_scanner() {
        return $this->option_scanner;
    }
}
